from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse, Http404, HttpResponseRedirect
from .models import ScrumyGoal, ScrumyUser, ScrumyStatus
from django.contrib import messages
from .forms import AddUser, AddTask, ChangeTask
from django.http import Http404
from django.urls import reverse
# from django.core.exceptions import ObjectDoesNotExist
# from store.exceptions import OutofStock


def index(request):
	# users = ScrumyUser.object.count()
	# for i in range(1, no_of_users + 1):
	# 	users = ScrumyUser.objects.get(pk=i)
	users = ScrumyUser.objects.all()
	context = {'users'  : users}
	return render(request, 'hammedscrumy/index.html', context)

def move_goal(request, task_id):

	try:
		goals = ScrumyGoal.objects.get(pk=task_id)
	except ScrumyGoal.DoesNotExist:
		raise Http404("No records exist for this id")
	context = {'goals':goals, 'task_id':task_id}
	return render(request, 'hammedscrumy/goals.html', context)

def add_user(request):
	if request.method == 'POST':
		form = AddUser(request.POST)
		if form.is_valid:
			form.save()
			return HttpResponseRedirect('hammedscrumy')
	else:
		form = AddUser()
		context = {'form' : form}
		return render(request, 'hammedscrumy/add_user.html', context)


def display_all(request):
	display = ScrumyUser.objects.all()
	output = ', '.join([output.userName for output in display])
	return HttpResponse(output)


def add_task(request):

	if request.method == "POST":
		form = AddTask(request.POST)
		if form.is_valid():
			form.save()
			return HttpResponseRedirect('hammedscrumy/index.html')
	else:
		form = AddTask()
	return render(request, 'hammedscrumy/add_task.html', {'form': form} ) 

def login_page(request):
	return render(request, 'registration/login.html')

def change_task(request, task_id):
	if request.method =="POST":
		form = ChangeTask(request.POST)
		if form.is_valid():
			new_status = request.POST.get('level')
			status = ScrumyStatus.objects.get(id=new_status)
			try:
				goal = ScrumyGoal.objects.get(id=task_id)
			except ScrumyGoals.DoesNotExist:
				raise Http404('There is no task with the id ')
			goal.save()
			return HttpResponseRedirect(reverse('hammedscrumy/index.html'))
	else:
		form = ChangeTask()
	context = {'form': form}
	return render(request, 'hammedscrumy/change_task.html', context)

