from django.db import models
from django.utils import timezone


class ScrumyUser(models.Model):
    ROLES = (
    ('ONR', 'Owner'),
    ('ADM', 'Admin'),
    ('QTA', 'Quality Analyst'),
    ('DEV', 'Developer'),
)
    name = models.CharField(max_length=150)
    email = models.EmailField(max_length=200)
    username = models.CharField(max_length=100, unique = True)
    password = models.CharField(max_length=15, blank = False)
    role = models.CharField(max_length=3, choices = ROLES, blank = False)

    class Meta:
        verbose_name_plural = 'ScrumyUser'

    def __str__(self):
        return self.name

class GoalStatus(models.Model):
    status = (
        ('DT', 'Daily task'),
        ('WT', 'Weekly task'),
        ('V', 'Verified'),
        ('D', 'Done'),
    )
    
    taskStatus = models.CharField(max_length=7, choices=status)
    completed_date = models.DateField(null = False)

    class Meta:
        verbose_name_plural = 'GoalStatus'

    def __str__(self):
        return self.taskStatus

class ScrumyGoals(models.Model):
    user_id = models.ForeignKey('ScrumyUser', on_delete=models.CASCADE)
    status_id = models.ForeignKey('GoalStatus', on_delete=models.CASCADE)
    task = models.TextField()
    task_id = models.IntegerField(default=600)
    status_time = models.DateTimeField(timezone.now)
    

    class Meta:
        verbose_name_plural = 'ScrumyGoals'

    def __str__(self):
        return self.task



