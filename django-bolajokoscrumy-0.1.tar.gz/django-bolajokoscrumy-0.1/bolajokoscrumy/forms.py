from django import forms
from .models import ScrumyUser

class UserForm(forms.ModelForm):
    class Meta:
        model = ScrumyUser
        fields = ('userName', 'firstName', 'lastName')