from django.apps import AppConfig


class UgwuscrumyConfig(AppConfig):
    name = 'ugwuscrumy'
