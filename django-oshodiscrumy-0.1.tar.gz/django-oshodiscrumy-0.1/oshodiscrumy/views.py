from django.shortcuts import render, redirect
from django.db import models
from django.views import generic
from django.http import Http404
from django.http import HttpResponseRedirect, HttpResponse
from .models import ScrumyUser, ScrumyGoals, GoalStatus
from .forms import AddUserForm, AddTaskForm, ScrumyGoalsForm
from django.urls import reverse
from django.contrib.auth.models import Group, Permission, User

class IndexView(generic.ListView):
    template_name = 'oshodiscrumy/index.html'
    context_object_name = 'users'

    def get_queryset(self):
        return ScrumyUser.objects.all()

def users(request):
    users = ScrumyUser.objects.all()
    return render(request, 'oshodiscrumy/users.html', {'users': users})

def move_task(request, task_id):
    task = ScrumyGoals.objects.get(pk = task_id)
    if request.method == 'POST':
        form = ScrumyGoalsForm(request.POST)
        user = request.user
        
        if user.has_perm("oshodiscrumy.DT_to_verified") and GoalStatus.objects.get(pk=2) == ScrumyGoals.objects.get(pk = task_id).goal_status:
            move_task = ScrumyGoals.objects.get(pk = task_id)
            move_task.goal_status = GoalStatus.objects.get(pk=3)
            move_task.save()
            return HttpResponse("The task has been successfully moved from daily tasks to verified")
        
        elif user.has_perm("oshodiscrumy.verified_to_done") and GoalStatus.objects.get(pk=3) == ScrumyGoals.objects.get(pk = task_id).goal_status:
            move_task = ScrumyGoals.objects.get(pk = task_id)
            move_task.goal_status = GoalStatus.objects.get(pk=4)
            move_task.save()
            return HttpResponse("The task has been successfully moved from verified to done")

        elif user.has_perm("oshodiscrumy.verify_to_done") and GoalStatus.objects.get(pk=1) == ScrumyGoals.objects.get(pk = task_id).goal_status:
            move_task = ScrumyGoals.objects.get(pk = task_id)
            move_task.goal_status = GoalStatus.objects.get(pk=2)
            move_task.save()
            return HttpResponse("The task has been successfully moved from weekly task to daily task")

        elif user.has_perm("oshodiscrumy.anywhere_to_anywhere"):
            new_status = request.POST['new_status']
            move_task = ScrumyGoals.objects.get(pk = task_id)
            ran = GoalStatus.objects.get(pk=4)
            move_task.goal_status = GoalStatus.objects.get(name = new_status)
            move_task.save()
            return HttpResponse(" The task has been successfully moved ")
        else:
            return HttpResponse("You do not have permission to move this task")
        
    else:
        form = ScrumyGoalsForm()
        all_status = GoalStatus.objects.filter(pk__range=(1,4))
        weekly_tasks = ScrumyGoals.objects.filter(goal_status = 1)
        tasks = ScrumyGoals.objects.get(pk = task_id).goal_status
        status = GoalStatus.objects.get(pk=2)
        context = {
            'form': form,
            'all_status': all_status,
            'weekly_tasks': weekly_tasks,
            'tasks': tasks,
            'task': task,
            'status': status
        }
    return render(request, 'oshodiscrumy/move_task.html', context)

class goals_view(generic.ListView):
    
    template_name = 'oshodiscrumy/goals_view.html'
    context_object_name = 'goals_object'

    def get_queryset(self):
        return ScrumyGoals.objects.all

# def move_goal(request, task_id):
#     try:
#         goals = ScrumyGoals.objects.get(task_id = task_id)
#     except ScrumyGoals.DoesNotExist:
#         raise Http404('There is no goal with the task_id')
#     return render(request, 'oshodiscrumy/goals.html', {'goals': goals, 'task_id': task_id})


def add_task(request):
    form = AddTaskForm()
    if request.method == "POST":
        form = AddTaskForm(request.POST)
        if form.is_valid:
            form.save()
            return redirect('index')
        else:
            return HttpResponse(AddTaskForm)
    return render(request, 'oshodiscrumy/add_task.html', {'form': form})

def add_user(request):
    form = AddUserForm()
    if request.method == "POST":
        form = AddUserForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
        else:
            return HttpResponse(AddUserForm)
    return render(request, 'oshodiscrumy/add_user.html', {'form': form})

# def change_task_status(request, goal_id):
#     form = ChangeTaskStatusForm
#     if request.method == "POST":
#         form = ChangeTaskStatusForm(request.POST)
#         if form.is_valid:
#             new_status = request.POST.get('status_id')
#             status = GoalStatus.objects.get(id = new_status)
#             try:
#                 goal = ScrumyGoals.objects.get(id = goal_id)
#             except ScrumyGoals.DoesNotExist:
#                 raise Http404('Ther is no goal with the id')
#             goal_status = goal.status_id
#             goal.save()
#             return HttpResponseRedirect('index')
#     else:
#         return HttpResponse(ChangeTaskStatusForm)
#     return render(request, 'oshodiscrumy/change_status.html', {'form': form})
#     # message = ''
    # if request.user.is_authenticated:
    #     current_user = request.user
    #     current_user_group = current_user.groups.add()
    #     if current_user_group:
    #         if request.method == "POST":
    #             form = ChangeTaskStatusForm(request.POST)
    #             if form.is_valid:
    #                 new_status = request.POST.get('status_id')
    #                 taskStatus = GoalStatus.objects.get(id = new_status)
    #                 try:
    #                     goal = ScrumyGoals.objects.get(id = goal_id)
    #                     goal_status = goal.status_id
    #                 except ScrumyGoals.DoesNotExist:
    #                 # Owner Permission
    #                     if str(current_user_group[0]) == 'OWNER':
    #                         goal.status_id = taskStatus
    #                 # Admin Permission
    #                     elif str(current_user_group[0]) == 'ADMIN':
    #                         if str(goal.status_id) == 'DT' and taskStatus.status == 'V':
    #                             goal.status_id = taskStatus
    #                     else:
    #                         print('No access granted to move to this status')
    #                 # # Quality Analyst Permission
    #                 #     elif str(current_user_group[0]) == 'QUALITY ANALYST':
    #                 #         if str(goal.status_id) == 'V' and taskStatus.status == 'D':
    #                 #             goal.status_id = taskStatus
    #                 #     else:
    #                 #         print('No access granted to move to this status')
    #                 # # Developer Permission
    #                 #     elif str(current_user_group[0]) == 'DEVELOPER':
    #                 #         if str(goal.status_id) == 'WT' and taskStatus.status == 'DT':
    #                 #             goal.status_id = taskStatus
    #                 #     else:
    #                 #         print('No access granted to move to this status')
    #                 else:
    #                     message += 'You do not have permission to change the goal status'
    #                     return HttpResponse('No permission defined for your group')
    #                 goal.save()
    #                 return HttpResponseRedirect('index')
    #             else:
    #                 form = ChangeTaskStatusForm()
    #             return render(request, 'oshodiscrumy/change_status.html', {'form': form})
    #         else:
    #             print('The user does not belong to any group')
    #             return HttpResponse('The user does not belong to any group')
    #     else:
    #         return HttpResponse('Access Denied, log in to access this page')

  

    
   