from django.db import models
from django.utils import timezone



class ScrumyUser(models.Model):
    User_Role = (
        ('O', 'Owner'),
        ('A', 'Admin'),
        ('Q', 'Quality Analyst'),
        ('D', 'Developer'),
        )
    userName = models.CharField(max_length=100, null=False)
    fullName = models.CharField(max_length=100, null=False)
    email = models.EmailField(max_length=100, null=False)
    role = models.CharField(max_length=10, choices=User_Role, default='User_role')
     
    def __str__(self):
        return self.userName


class ScrumyStatus(models.Model):
    STATUS = (
        ('WT', 'Weekly Task'),
        ('DT', 'Daily Task'),
        ('V', 'Verified'),
        ('D', 'Done'),
    )
    status = models.CharField(max_length=70, choices=STATUS)

    def __str__(self):
        return self.status


class ScrumyGoal(models.Model):
    user_id = models.ForeignKey(ScrumyUser, on_delete=models.CASCADE, related_name = 'userid')
    level = models.ForeignKey(ScrumyStatus, on_delete=models.CASCADE, related_name = 'level')
    goals = models.TextField(max_length=300)
    description = models.TextField(max_length=300, null=False)
    date_created = models.DateTimeField(default=timezone.now)
    date_updated = models.DateTimeField(auto_now=True)
    task_id = models.IntegerField(default=0)

    def __str__(self):
        return self.goals + "  " + str(self.date_created)
