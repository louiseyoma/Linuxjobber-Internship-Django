#!/usr/bin/env python
import os
from setuptools import setup, find_packages

setup(name='django-okoroscrumy',
      version='1.0',
      description='Okoroscrumy project management application',
      author='Nnamdi Okoroscrumy',
      author_email='nnamsok@gmail.com',
      packages= find_packages()
     )
