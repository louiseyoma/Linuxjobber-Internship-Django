from django.shortcuts import render
from django.http import HttpResponse, HttpResponseBadRequest, HttpResponseNotFound, Http404, HttpResponseRedirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login
from .forms import AddNewUserForm, AddTaskForm, ChangeTaskStatusForm

# Import Models
from .models import ScrumyUser, ScrumyGoals, GoalStatus

# Create your views here.
# @login_required(login_url='/accounts/login/')
def index(request):
  try:
    users = ScrumyUser.objects.all() 
    # goalstatus
    daily_status = GoalStatus.objects.get(status='DT')
    weekly_status = GoalStatus.objects.get(status='WT')
    verified_status = GoalStatus.objects.get(status='V')
    done_status = GoalStatus.objects.get(status='D')

  except ScrumyUser.DoesNotExist:
    raise Http404('User does not exist')

  context = {
    "users": users,
    "daily_status": daily_status,
    "weekly_status": weekly_status,
    "verified_status": verified_status,
    "done_status": done_status,
  }
  return render(request, 'emmascrumy/index.html', context)


#================================ Add usr view=========================
def add_user(request):
   # if this is a POST request we need to process the form data
  if request.method == 'POST':
    # create a form instance and populate it with data from the request:
    form = AddNewUserForm(request.POST)
    if form.is_valid:
      form.save()
      return HttpResponseRedirect('User successfully created')
  else:
    form = AddNewUserForm()
    context = {'form': form}
  return render(request, 'emmascrumy/add_user.html', context)


#=============================== Move goal view =======================
def move_goal(request):
  goal = ScrumyGoals.objects.get(id=task_id)
  return HttpResponse(goal.task)


#================================ Add task view =======================
def add_task(request):
  if request.method == 'POST':
    form = AddTaskForm(request.POST)
    if form.is_valid:
      form.save()
      return HttpResponseRedirect('New Task added successfully')
  else:
    form = AddTaskForm()
    context = {"form": form}
  return render(request, 'emmascrumy/add_task.html', context)



#============================== Error views ===========================
def handler404(request, exception):
  return render (request, 'emmascrumy/404.html', status=404)

def handler500(request, exception):
  return render(request, 'emmascrumy/500.html', status=500)