from django.shortcuts import render
from django.http import HttpResponse
from .models import ScrumyGoals, ScrumyUser

def homepage(request):
 a = ScrumyGoals.objects.all()
 return HttpResponse(a)

#create your views here