from django import  forms
from .models import ScrumyGoals,ScrumyUser,GoalStatus


class UserForm(forms.ModelForm):
    class Meta:
        model = ScrumyUser
        fields = '__all__'


class TaskForm(forms.ModelForm):
   class Meta:
    model = ScrumyGoals
    fields = '__all__'
    exclude=['user','goal']


class TaskStatus(forms.ModelForm):

  class Meta:
    model = GoalStatus
    fields = '__all__'
