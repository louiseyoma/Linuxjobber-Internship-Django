from .models import AppUsers, ContactUs
from django import forms


GENDER_CHOICES= [
    ('First choice', 'I am...'),
    ('Male', 'Male'),
    ('Female', 'Female'),
    ]

COUNTRY_CHOICES= [
    ('Nigeria', 'Nigeria'),
    ('England', 'England'),
    ('France', 'France'),
    ('Germany', 'Germany'),
    ('Italy', 'Italy'),
    ('United States', 'United States'),
    ]

YEARS= [x for x in range(1920,2017)]







class AppUsersForm(forms.ModelForm):
    username = forms.CharField(widget = forms.TextInput(attrs = {'style' : 'width: 100%; height:30px' }) )
    first_name = forms.CharField(widget = forms.TextInput(attrs = {'style' : 'width: 100%; height:30px' }) )
    last_name = forms.CharField(widget = forms.TextInput(attrs = {'style' : 'width: 100%; height:30px' }) )
    password1 = forms.CharField(label='Password', widget=forms.PasswordInput
        (attrs = {'style' : 'width: 100%; height:30px' }))
    password2 = forms.CharField(label='Confirm Password', widget=forms.PasswordInput
        (attrs = {'style' : 'width: 100%; height:30px' }))
    birth_date= forms.DateField(widget=forms.SelectDateWidget(years=YEARS))
    gender= forms.CharField(widget=forms.Select(choices=GENDER_CHOICES))
    phone_no = forms.CharField(widget = forms.TextInput(attrs = {'style' : 'width: 100%; height:30px' }) )
    email = forms.CharField(widget = forms.TextInput(attrs = {'style' : 'width: 100%; height:30px' }) )  
    location= forms.CharField(widget=forms.Select(choices=COUNTRY_CHOICES))
    class Meta:
        model = AppUsers
        fields= ["username","first_name", "last_name", "password1", "password2", 
				 "birth_date", "gender", "phone_no", "email", "location"]

class ContactUsForm(forms.ModelForm):
    name = forms.CharField(widget = forms.TextInput(attrs = {'style' : 'width: 100%;' }) )
    email = forms.EmailField(widget = forms.EmailInput(attrs ={ 'style' : 'width: 100%;' }))
    message = forms.CharField(max_length = 2000 ,widget = forms .Textarea(attrs ={ 'style' : 'width: 100%;' }))

    class Meta:
            model = ContactUs
            fields= ["name","email", "message"]





