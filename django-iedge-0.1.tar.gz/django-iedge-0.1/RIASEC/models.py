from django.db import models
from .validators import(validate_firstname_length, validate_lastname_length,validate_username_length, validate_username_alphadigits,validate_password_length, validate_password_digit, validate_password_uppercase, validate_phonenumber)




class AppUsers(models.Model):
	username = models.CharField(max_length=25, verbose_name= 'User name', validators= [validate_username_length, validate_username_alphadigits])
	first_name = models.CharField(max_length=100, verbose_name='Last name', validators= [validate_lastname_length])
	last_name = models.CharField(max_length=100, verbose_name='First name', validators= [validate_firstname_length])
	password1 = models.CharField(max_length=30, validators=[validate_password_length, validate_password_digit, validate_password_uppercase])
	password2 = models.CharField(max_length=30)
	email = models.EmailField()
	phone_no = models.CharField(max_length= 15, validators= [validate_phonenumber])
	birth_date= models.DateField(verbose_name='What is your birth date?')
	gender= models.CharField(max_length=6)
	location= models.CharField(max_length=100, default = 'Nigeria' )
	# roles = (
	# 	(1, 'Admin'),
	# 	(2, 'User'),
	# )	
	# AppUserRole = models.PositiveSmallIntegerField(choices = roles)
	def __str__(self):
		return '{} {} {} '.format(self.username,self.first_name,self.last_name)
	class  Meta:
		verbose_name_plural = 'AppUsers'
			



class Questions(models.Model):
	question = models.CharField(max_length = 2000, verbose_name = 'Question')
	question_group = models.CharField (max_length = 100, verbose_name = 'Question Group')
	# choices = (
	# 	(1, 'Yes'),
	# 	(2, 'No'),
	# )
	# answer = models.ChoiceField(max_length=2, choices = choices)
	def __str__(self):
		return '{} {}'.format(self.question,self.question_group)
	class  Meta:
		verbose_name_plural = 'Questions'


class Results(models.Model):
	name = models.CharField(max_length = 25, verbose_name = 'Name',)
	preamble = models.CharField(max_length = 2000, verbose_name = 'Preamble')
	major1 = models.CharField(max_length = 50, null = True)
	major2 = models.CharField(max_length = 50, null = True)
	major3 = models.CharField(max_length = 50, null = True)
	major4 = models.CharField(max_length = 50, null = True)
	major5 = models.CharField(max_length = 50, null = True)
	major6 = models.CharField(max_length = 50, null = True)
	major7 = models.CharField(max_length = 50, null = True)
	related_pathway1 = models.CharField(max_length = 50, null = True)
	related_pathway2 = models.CharField(max_length = 50, null = True)
	related_pathway3 = models.CharField(max_length = 50, null = True, blank = True)
	related_pathway4 = models.CharField(max_length = 50, null = True, blank = True)
	def __str__(self):
		return '{} {} {} {} {} {} {} {} {} {} {} {} {}'.format(self.name,self.preamble,
			self.major1, self.major2, self.major3, self.major4, self.major5, self.major6, self.major7,
			self.related_pathway1, self.related_pathway2, self.related_pathway3, self.related_pathway4)
	class  Meta:
		verbose_name_plural = 'Results'		



class Questionaires(models.Model):
	question = models.CharField(max_length = 2000, verbose_name = 'Question')
	question_group = models.CharField (max_length = 100, verbose_name = 'Question Group')
	def __str__(self):
		return '{} {}'.format(self.question,self.question_group)
	class  Meta:
		verbose_name_plural = 'Questionaires'



class UserResult(models.Model):
	app_user = models.ForeignKey(AppUsers, on_delete = models.CASCADE)
	name = models.CharField(max_length = 25, verbose_name = 'Name',)
	preamble = models.CharField(max_length = 2000, verbose_name = 'Preamble')
	major1 = models.CharField(max_length = 50, null = True)
	major2 = models.CharField(max_length = 50, null = True)
	major3 = models.CharField(max_length = 50, null = True)
	major4 = models.CharField(max_length = 50, null = True)
	major5 = models.CharField(max_length = 50, null = True)
	major6 = models.CharField(max_length = 50, null = True)
	major7 = models.CharField(max_length = 50, null = True)
	related_pathway1 = models.CharField(max_length = 50, null = True)
	related_pathway2 = models.CharField(max_length = 50, null = True)
	related_pathway3 = models.CharField(max_length = 50, null = True, blank = True)
	related_pathway4 = models.CharField(max_length = 50, null = True, blank = True)
	def __str__(self):
		return '{}     {}'.format(self.name,self.preamble)
	class  Meta:
		verbose_name_plural = 'User Result'



class ContactUs(models.Model):
	full_name = models.CharField(max_length = 25, verbose_name = 'Full Name')
	email = models.EmailField(verbose_name = 'Email')
	message = models.TextField(max_length = 50, null = True, verbose_name = 'Message')
	def __str__(self):
		return '{} {} {} {} {} {} {} {} {} {} {} {} {}'.format(self.name,self.preamble,
			self.full_name, self.email, self.message)
	class  Meta:
		verbose_name_plural = 'User Result'

