from django.apps import AppConfig


class EyomascrumyConfig(AppConfig):
    name = 'eyomascrumy'
