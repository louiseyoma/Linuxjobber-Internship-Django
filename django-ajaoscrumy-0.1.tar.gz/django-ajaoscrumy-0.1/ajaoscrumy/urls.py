from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('task/<task_id>/', views.move_goal, name='move-goal'),
    path('user/add/', views.add_user, name='add_user'),
    path('user/list/', views.list_of_users, name='list_of_users'),


]