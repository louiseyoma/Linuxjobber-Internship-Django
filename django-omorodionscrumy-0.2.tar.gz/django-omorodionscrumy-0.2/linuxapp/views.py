from django.shortcuts import render
from django.http import HttpResponse
from .models import User,TaskId
# Create your views here.

def homepage(request):
    return HttpResponse("<h1>Hello world</h1>")

def home(request):
    a = TaskId.objects.all()
    return HttpResponse(a)