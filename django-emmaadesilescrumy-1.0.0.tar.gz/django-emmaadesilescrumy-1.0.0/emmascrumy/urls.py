from django.urls import path
from . import views


urlpatterns = [
  path('', views.index, name='index'),
  path('add_task/<int:task_id>', views.add_task, name='add_task'),
  path('move_goal/<int:task_id>', views.move_goal, name='move_goal'),
  path('add_user/<str:new_user>', views.add_user, name='add_user'),
]
