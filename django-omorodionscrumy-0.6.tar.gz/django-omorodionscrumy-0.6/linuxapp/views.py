from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse
from .models import User,TaskId
# Create your views here.

def homepage(request):
    goals = TaskId.objects.get(pk= 1)
    context = {'goals' : goals}
    template = loader.get_template ('linuxapp/home.html')
    return HttpResponse(template.render(context, request))

def home(request):
    a = TaskId.objects.all().filter(task_category='daily goal')
    return HttpResponse(a)

def addTask(request,usersView):
    return HttpResponse("Hello %s please edit or add a new task" % usersView ) 

def addUser(request):
    user = User(userName = 'mike')
    user.save()
    users = User.objects.all()
    output = ', '.join([eachuser.userName for eachuser in users])
    return HttpResponse(output)


