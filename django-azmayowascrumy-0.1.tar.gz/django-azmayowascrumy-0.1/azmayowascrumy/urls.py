from django.urls import path
from . import views
app_name='azmayowascrumy'
urlpatterns=[
    # /
    path('',views.index,name='index'),
    path('add_user',views.add_user,name='add_user'),
    path('goals/',views.goal_list,name='goal-index'),
    path('goals/<int:goal_id>',views.goal_detail,name='goal-detail'),
    path('goals/<int:goal_id>/tasks', views.tasks_list, name='goal-detail'),
    path('goals/<int:goal_id>/tasks/<int:task_id>', views.task_detail, name='goal-detail'),
]