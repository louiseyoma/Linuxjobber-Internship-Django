from django.urls import path, re_path
from . import views



urlpatterns = [
    path('index/',views.Index,name="index"),
    path('task/<int:task_id>/',views.Move_goal,name="move_goal"),
    path('add_user/',views.Add_user,name="add_user"),
    
]