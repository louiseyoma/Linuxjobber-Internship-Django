from django import forms
from .models import ScrumyUser, ScrumyGoals, GoalStatus

class UserForm(forms.ModelForm):
    username = forms.CharField(label='Enter Username', max_length=100, widget=forms.TextInput(attrs={'class':'form-control'}))
    password1 = forms.CharField(label='Password', widget=forms.PasswordInput(attrs={'class': 'form-control'}))
    password2 = forms.CharField(label='Confirm Password', widget=forms.PasswordInput(attrs={'class': 'form-control'}))
    email = forms.CharField(label='Enter Email', max_length=100, widget=forms.TextInput(attrs={'class':'form-control'}))
    role = forms.CharField(label='Choose User Role',max_length=1, widget=forms.Select(choices=ScrumyUser.USERROLE, attrs={'class': 'form-control'}))

    class Meta:
        model = ScrumyUser
        fields = ['username', 'password1', 'password2', 'email', 'role']

class GoalForm(forms.ModelForm):
    goal_status = forms.ModelChoiceField(label='Enter Goal Status', queryset=GoalStatus.objects.all(), widget=forms.Select(attrs={'class': 'form-control'}))
    goals = forms.CharField(label='Enter Goals', widget=forms.Textarea(attrs={'class': 'form-control'}))
  
    class Meta:
        model = ScrumyGoals
        fields = ['goal_status', 'goals']



class StatusForm(forms.ModelForm):
	class Meta:
		model = GoalStatus
		fields = ['name']
    
