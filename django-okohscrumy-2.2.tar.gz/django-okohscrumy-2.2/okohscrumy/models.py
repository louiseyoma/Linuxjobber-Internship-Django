from django.db import models
from django.utils import timezone

# Create your models here.
class ScrumyUser(models.Model):
    USERROLE = (
        ('O', 'Owner'),
        ('A', 'Admin'),
        ('Q', 'Quality Analyst'),
        ('D', 'Developer'),
    )
    username = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    role = models.CharField(max_length=1, default="", choices=USERROLE)
    def __str__(self):
        return self.username

    class Meta:
        verbose_name_plural = "Scrumy Users"


class GoalStatus (models.Model):
   STATUS = (
       ('P', 'Pending'),
       ('V', 'Verified'),
       ('D', 'Done'),
   )
   status = models.CharField(max_length=1, choices=STATUS)
   VerifiedBy = models.ForeignKey(ScrumyUser, on_delete=models.CASCADE)
   
   class Meta:
        verbose_name_plural = "Goal  Status"


class ScrumyGoals(models.Model):
    GOALTYPE = (
        ('WG', 'Weekly Goal'),
        ('DT', 'Daily Task'),
    )
    user = models.ForeignKey(ScrumyUser, on_delete=models.CASCADE)
    status_id = models.ForeignKey(GoalStatus, default="", on_delete=models.CASCADE)
    goalType = models.CharField(max_length=2, default="", choices=GOALTYPE)
    task = models.TextField()
    duration = models.DateTimeField('Duration to Finish Task')
    date_created = models.DateTimeField(default=timezone.now)
    date_updated = models.DateTimeField(null=True, blank=True)
    def __str__(self):
        return self.task

    class Meta:
        verbose_name_plural = "Scrumy Goals"



    



    
