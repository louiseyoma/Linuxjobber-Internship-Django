from django.urls import path, re_path
from eyomascrumy import views

app_name = 'eyomascrumy'

urlpatterns = [
	path('',views.homepage, name = 'homepage'),
]