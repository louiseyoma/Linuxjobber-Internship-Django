==========
AjaoScrumy
==========

AjaoScrumy is a simple Django web app to project management. It is modelled around the scrum way of
managing projects.


Quick start
==========

1. Add "polls" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
    ...
    'ajaoscrumy',

    ]

2. Include the ajaoscrumy URLconf in your project urls.py like this::
path('ajaoscrumy/', include('ajaoscrumy.urls')),
3. Run `python manage.py migrate` to create the polls models.
4. Start the development server and visit http://127.0.0.1:8000/admin/
to create a scrum (you'll need the Admin app enabled).
5. Visit http://127.0.0.1:8000/ajaoscrumy/ to participate in the poll.