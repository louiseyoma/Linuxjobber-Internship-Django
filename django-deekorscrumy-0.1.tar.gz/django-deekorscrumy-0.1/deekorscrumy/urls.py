from django.urls import path
from . import views

app_name = 'deekorscrumy'

urlpatterns = [
    path('',views.index,name='index'), 
    path('<int:task_id>/',views.move_goal, name='goal'),
    path('register', views.add_user, name='register'),
    path('users', views.UsersIndex.as_view(), name='users'),
    path('show_users', views.show_users)
]