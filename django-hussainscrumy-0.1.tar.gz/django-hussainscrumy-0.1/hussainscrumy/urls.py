from django.urls import path
from . import views

urlpatterns = [
    path('',  views.homepage, name = 'homepage'),
    path('home/', views.home, name='home'),
    path('<str:usersView>/', views.addTask, name='addTask'),
    path('user/adduser/', views.addUser, name='addUser'),
]