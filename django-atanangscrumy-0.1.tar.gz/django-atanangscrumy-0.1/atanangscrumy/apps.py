from django.apps import AppConfig


class AtanangscrumyConfig(AppConfig):
    name = 'atanangscrumy'
