from django.apps import AppConfig


class OwolabiscrumyConfig(AppConfig):
    name = 'owolabiscrumy'
