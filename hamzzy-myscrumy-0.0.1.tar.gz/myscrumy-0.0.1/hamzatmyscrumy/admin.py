from django.contrib import admin

# Register your models here.
from .models import ScrumyGoals,GoalStatus, ScrumyUser
# Register your models here.

class UserAdmin(admin.ModelAdmin):
    list_filter = ['id','username','first_name','last_name']
    list_display = ['id','username','first_name','last_name','email']

admin.site.register(ScrumyUser,UserAdmin)



class GoalsAdmin(admin.ModelAdmin):
    list_display = ['id','user_goal', 'task', 'description', 'date_created']
admin.site.register(ScrumyGoals,GoalsAdmin)



class GoalsStatusAdmin(admin.ModelAdmin):
    list_display = ['id', 'weekly_target', 'status','daily_target','verify']

admin.site.register(GoalStatus,GoalsStatusAdmin)