from django.shortcuts import render
from django.http import HttpResponse
from .models import ScrumyGoals,ScrumyUser
# Create your views here.

def homepage(request):
  return HttpResponse("<h1>Hello world!</h1>")

def home(request):
  a = ScrumyGoals.objects.all().filter(task_category='daily goals')
  return HttpResponse(a)

def addTask(request, usersView):
  return HttpResponse('Hello %s please edit or add a new task' %usersView)

def addUser(request):
  user = ScrumyUser(userName='mike')
  user.save()
  users = ScrumyUser.objects.all()
  output = ' ,'.join([eachUser.userName for eachUser in users])
  return HttpResponse(output)

def table(request):
  goals = ScrumyGoals.objects.get(pk=1);
  context = {"myGoals":goals}
  return render(request, 'hussainscrumy/home.html', context )