from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse, Http404

from .models import User, Task
from .forms import UserForm

# Create your views here.


def index(request):
    hello_world = 'Hello world'
    return render(request, 'ajaoscrumy/index.html', {'hello_world': hello_world})


def move_goal(request, task_id):
    task = get_object_or_404(Task, task_id)
    return HttpResponse(task)


def add_user(request):
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.user = request.user
            user.save()
            return redirect('list_of_users')
    else:
        form = UserForm()
    return render(request, 'ajaoscrumy/add_user.html', {'form': form})


def list_of_users(request):
    users = User.objects.all()
    return render(request, 'ajaoscrumy/list_of_users.html', {'users': users})


def get_user(request, pk):
    try:
        user = User.objects.get(pk=pk)
    except User.DoesNotExist:
        raise Http404
    return render(request, 'ajaoscrumy/index.html', {'user': user})


