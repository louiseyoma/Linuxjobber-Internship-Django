from django.apps import AppConfig


class OderascrumyConfig(AppConfig):
    name = 'oderascrumy'
