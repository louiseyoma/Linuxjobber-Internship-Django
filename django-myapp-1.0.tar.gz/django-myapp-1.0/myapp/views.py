from django.shortcuts import render, render_to_response
from django.http import Http404
from .forms import AddTaskForm, AddUserForm, ChangeTaskForm
from django.views.decorators.csrf import csrf_protect
# Create your views here.
from django.http import HttpResponse, HttpResponseRedirect
from .models import ScrummyUser, ScrummyGoals, GoalStatus
from django.template.response import TemplateResponse

def index(request):
    #num_user = ScrummyUser.objects.all()
    #name = len(num_user)

    #goals = []
    try:
        num_user = ScrummyUser.objects.all()
        con = {'user':num_user}
        return TemplateResponse(request, 'myapp/index.html', con)
    except ScrummyUser.DoesNotExist as e:
        raise Http404("Object does not exist")



def filter(request, task_id):
    var = GoalStatus.objects.filter(pk=task_id)

    #output = " ".join([c.user_name_id for c in var])
    out = " ".join([q.day_target for q in var])
    return HttpResponse("The Goal status for day target id %s is %s " % (task_id, out))

def move_goal(request, task_id):
    if request.POST:
        form = ChangeTaskForm(request.POST)
        if form.is_valid():
            form.save()

            return HttpResponseRedirect('myapp/index.html')

    else:
        form = ChangeTaskForm()

    args = {'form':form}

    return render_to_response('myapp/move_task.html', args)

def add_task(request):
    try:
        if request.POST:
            form = AddTaskForm(request.POST)
            if form.is_valid():
                form.save()

                return HttpResponseRedirect('myapp/index.html')

        else:
            form = AddTaskForm()

        args = {'form':form}

        return render_to_response('myapp/add_task.html', args)
    except ScrummyGoals.DoesNotExist:
        raise Http404("No records exists for this id")
    #output = "  ".join([c.task for c in var])
    #out = "<br> ".join([q.week_target for q in var])


def add_user(request):
    if request.POST:
        form = AddUserForm(request.POST)
        if form.is_valid():
            form.save()

            return HttpResponseRedirect('myapp/index.html')

    else:
        form = AddUserForm()

    args = {'form':form}

    return render_to_response('myapp/add_user.html', args)


