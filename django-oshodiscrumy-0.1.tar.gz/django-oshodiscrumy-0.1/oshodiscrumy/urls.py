from django.urls import path

from . import views


urlpatterns = [
    path('', views.index, name = 'index'),
    path('users/', views.users, name = 'users'),
    path('add_user/', views.add_user, name = 'add_user'),
    path('add_task/', views.add_task, name = 'add_task'),
    path('<int:goal_id>/changestatus/', views.change_task_status, name = 'change_task_status'),
]