from django.db import models


STATUS = (
	('WT', 'Weekly Task'),
	('DT', 'Daily Task'),
	('V', 'Verified'),
	('D', 'Done'),
)

class ScrumyUser(models.Model):
	userName = models.CharField(max_length = 100, blank=True, null=False)
	firstName = models.CharField(max_length = 100, null=False)
	lastName = models.CharField(max_length = 100, null=False)
		
	def __str__(self):
		return self.userName


class GoalStatus(models.Model):
	status = models.CharField(max_length=50, choices=STATUS)
	
	def __str__(self):
		return self.status
		
class ScrumyGoals(models.Model):
	user_id = models.ForeignKey(ScrumyUser, on_delete = models.CASCADE)
	status_id = models.ForeignKey(GoalStatus, on_delete = models.CASCADE)
	task = models.TextField()
	task_id = models.IntegerField(default=700, null=False)
	moved_by = models.CharField(max_length=50, null=False)
	created_by = models.CharField(max_length=50, null=False)
	movement_track = models.IntegerField(default=1234, null=False)

	

	def __str__(self):
		return self.task


	

	
