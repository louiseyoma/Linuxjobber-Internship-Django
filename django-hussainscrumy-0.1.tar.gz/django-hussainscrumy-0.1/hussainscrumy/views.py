from django.shortcuts import render
from django.http import HttpResponse,Http404
from .models import ScrumyGoals,ScrumyUser
# Create your views here.

def homepage(request):
  try:
    users = ScrumyUser.objects.get(pk=1)
  except ScrumyUser.DoesNotExist:
    raise Http404("user does not exist")
  return render(request, "hussainscrumy/home.html", {'users':users})

def home(request):
  a = ScrumyGoals.objects.all().filter(task_category='daily goals')
  return HttpResponse(a)

def addTask(request, usersView):
  return HttpResponse('Hello %s please edit or add a new task' %usersView)

def addUser(request):
  user = ScrumyUser(userName='mike')
  user.save()
  users = ScrumyUser.objects.all()
  output = ' ,'.join([eachUser.userName for eachUser in users])
  return HttpResponse(output)

def table(request):
  goals = ScrumyGoals.objects.get(pk=1);
  context = {"myGoals":goals}
  return render(request, 'hussainscrumy/home.html', context )

def findUser(request, username):
  try:
    user = ScrumyUser.objects.get(userName=username)
  except ScrumyUser.DoesNotExist:
    raise Http404("user does not exist")
  
  return render(request, "hussainscrumy/users.html", {'user':user})