from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.urls import reverse
from django.views.generic.edit import FormMixin

from .models import GoalStatus,ScrumyGoals,ScrumyUser,UserManager
from .forms import UserForm,TaskForm,TaskStatus
# Create your views here.
from django.views.generic import ListView, CreateView



def Index(request):
    ''' target=GoalStatus.objects.filter(daily_target='to finish the task',status=1)
    for n in target:
        pass
    ta=[  n.status , n.daily_target , n.weekly_target]
    '''
    use_no = ScrumyUser.objects.count()
    for r in range(1,use_no):
        pass
    user = ScrumyUser.objects.filter(id=r)
    for n in user:
        print(n.username)
    goal=ScrumyGoals.objects.get_user_scrum_goal(n.id)
    context={
        'user':user,
        'goal':goal
    }

    return render(request,'index.html',context=context)

def Move_goal(request,task_id):

       task=get_object_or_404(ScrumyGoals,id=task_id)
       form =TaskForm(request.POST)
       if form.is_valid():
           form.save(commit=True)
           return HttpResponseRedirect(reverse('index'))
       else:
           form = TaskForm()


       return  render(request,'move_task.html',{'form':form})





def Add_user(request):
   form=UserForm(request.POST)
   if form.is_valid():
       form.save(commit=True)
       return HttpResponseRedirect(reverse('index'))
   context={
       'form':form
   }

   return render(request,'add_user.html',context=context)


class Goal(ListView,FormMixin):
    model = ScrumyGoals
    template_name ='goal.html'
    form_class = TaskStatus
