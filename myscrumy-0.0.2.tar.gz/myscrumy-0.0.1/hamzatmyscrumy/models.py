from django.db import models

# Create your models here.

class UserManager(models.Manager):
    def get_user_scrum_goal(self,id):
          return self.filter(user_id=id)


class ScrumyUser(models.Model):

    ROLE=(
        ('OW',('owner')),
        ('AD', ('Admin')),
        ('QA', ('quality assurance')),
        ('DEV', ('Developer')),
    )
    username=models.CharField(max_length=300)
    first_name=models.CharField(max_length=300)
    last_name=models.CharField(max_length=300)
    role=models.CharField(choices=ROLE,max_length=300,blank=True)
    class Meta:
      def __str__(self):
       return self.username



class GoalStatus(models.Model):
    STATUS_TODO = 1
    STATUS_IN_PROGRESS = 2
    STATUS_TESTING = 3
    STATUS_DONE = 4
    STATUS_CHOICES = (
        (STATUS_TODO,('Not Started')),
        (STATUS_IN_PROGRESS,('In Progress')),
        (STATUS_TESTING,('Testing')),
        (STATUS_DONE, ('Done')),
    )
    weekly_target=models.CharField(max_length=300)
    status = models.SmallIntegerField(choices=STATUS_CHOICES, default=STATUS_TODO)
    daily_target=models.CharField(max_length=300)
    verify =models.BooleanField()

class ScrumyGoals(models.Model):
    user=models.ForeignKey(ScrumyUser,on_delete=models.CASCADE)
    goal = models.ForeignKey(GoalStatus, on_delete=models.CASCADE,default='')
    objects=UserManager()
    task=models.CharField(max_length=300,null=True)
    description=models.TextField()
    date_created=models.DateTimeField(auto_now=True)
    date_updated=models.DateTimeField(auto_now=True,blank='')
    class Meta:
      def __str__(self):
       return self.scrumy




