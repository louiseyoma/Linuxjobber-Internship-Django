from django.db import models
# from django.core.urlresolvers import reverse

# Create your models here.

class ScrumyUser(models.Model):
    name = models.CharField(max_length=100)
    email = models.CharField(max_length=150)
    roles = models.CharField(max_length=50)

    # def get_absolute_url(self):
    #     return reverse('deekorscrumy:users', kwargs={'pk': self.pk})

    def __str__(self):
        return self.name

class GoalStatus(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class ScrumyGoals(models.Model):
    user = models.ForeignKey(ScrumyUser, on_delete=models.CASCADE)
    goalStat = models.ForeignKey(GoalStatus, on_delete=models.CASCADE)
    goalName = models.CharField(max_length=100)
    desc = models.CharField(max_length=250)
    date = models.DateField(max_length=100)
    time = models.TimeField(max_length=100)

    def __str__(self):
        return self.goalName



