from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from .models import ScrummyUser, ScrummyGoals, GoalStatus

def index(request):
    return HttpResponse("Welcome to the homepage.")

def filter(request, task_id):
    var = GoalStatus.objects.filter(pk=task_id)
    #output = " ".join([c.user_name_id for c in var])
    out = " ".join([q.day_target for q in var])
    return HttpResponse("The Goal status for day target id %s is %s " % (task_id, out))

def move_goal(request, task_id):
    var = ScrummyGoals.objects.filter(pk=task_id)
    #output = " ".join([c.user_name_id for c in var])
    out = " ".join([q.task for q in var])
    return HttpResponse("The task for id %s is %s "%(task_id, out))


def add_user(request):
   # var = ScrummyUser.objects.create(name=user, email=email, roles=role)
    var1 = ScrummyUser.objects.all()
    out = " , ".join([q.name for q in var1])
    return HttpResponse(out)


