Okoroscrumy is a project management application used to assign tasks to team members and have a report about the task given.
