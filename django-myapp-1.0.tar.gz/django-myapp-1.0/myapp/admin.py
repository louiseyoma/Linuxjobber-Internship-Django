from django.contrib import admin
from .models import ScrummyUser, ScrummyGoals, GoalStatus
# Register your models here.

admin.site.register(ScrummyUser)
admin.site.register(ScrummyGoals)
admin.site.register(GoalStatus)