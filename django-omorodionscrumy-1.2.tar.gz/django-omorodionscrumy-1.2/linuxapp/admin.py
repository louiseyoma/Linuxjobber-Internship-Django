from django.contrib import admin

# Register your models here.
from . models import UserName,TaskId,Taskcategory

admin.site.register(UserName)
admin.site.register(TaskId)
admin.site.register(Taskcategory)