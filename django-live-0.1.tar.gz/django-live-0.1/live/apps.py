from django.apps import AppConfig


class LiveConfig(AppConfig):
    name = 'live'
