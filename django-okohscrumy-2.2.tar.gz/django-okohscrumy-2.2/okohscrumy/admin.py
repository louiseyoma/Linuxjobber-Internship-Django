from django.contrib import admin

from .models import ScrumyUser
from .models import ScrumyGoals
from .models import GoalStatus


class ScrumyUserAdmin(admin.ModelAdmin):
    list_display = ('username', 'email', 'role')

admin.site.register(ScrumyUser, ScrumyUserAdmin)
admin.site.register(ScrumyGoals)
admin.site.register(GoalStatus)