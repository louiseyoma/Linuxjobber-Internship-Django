from django.apps import AppConfig


class NwanzescrumyConfig(AppConfig):
    name = 'nwanzescrumy'
