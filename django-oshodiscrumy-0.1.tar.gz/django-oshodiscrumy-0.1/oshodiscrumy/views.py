from django.shortcuts import render, redirect
from django.http import Http404
from django.http import HttpResponse
from django.contrib import messages
from django.contrib.auth import authenticate, login
from .models import ScrumyUser, ScrumyGoals, GoalStatus
from .forms import AddUserForm, AddTaskForm, ChangeTaskStatusForm



def index(request):
    try:
        users = ScrumyUser.objects.all()
        for user in users:
            goal = GoalStatus.objects.filter(taskStatus = 'WT')

    except ScrumyUser.DoesNotExist:
        raise Http404("user does not exist")
    return render(request, 'oshodiscrumy/index.html', {'users': users})
    

def add_task(request):
    if request.method == "POST":
        form = AddTaskForm(request.POST)
        if form.is_valid:
            form.save()
            return redirect('oshodiscrumy:tasks')
    else:
        form = AddTaskForm()
        return render(request, 'oshodiscrumy/add_task.html', {'form': form})

def add_user(request):
    if request.method == "POST":
        form = AddUserForm(request.POST)
        if form.is_valid:
            form.save()
            return redirect('oshodiscrumy:users')
    else:
        form = AddUserForm()
        return render(request, 'oshodiscrumy/add_user.html', {'form': form})

def users(request):
    users = ScrumyUser.objects.all()
    return render(request, 'oshodiscrumy/users/html', {'users': users})

def change_task_status(request, goal_id):
    if request.method == "POST":
        Form = ChangeTaskStatusForm(request.POST)
        if form.is_valid:
            new_status = request.POST.get('status_id')
            taskStatus = GoalStatus.objects.get(id = new_status)
            try:
                goal = ScrumyGoals.objects.get(id = goal_id)
            except ScrumyGoals.DoesNotExist:
                raise Http404('there is no goal with the id')
            goal.status_id = status_id
            goal.save()
            return redirect('oshodiscrumy:index')
    else:
        form = ChangeTaskStatusForm()
        return render(request, 'oshodiscrumy/change_status.html', {'form': form})
    
    
