from django.urls import path, re_path
from eyomascrumy import views

app_name = 'eyomascrumy'

urlpatterns = [
	re_path(r'^$',views.homepage, name = 'homepage'),
]