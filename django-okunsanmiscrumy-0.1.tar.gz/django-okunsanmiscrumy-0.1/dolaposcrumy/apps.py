from django.apps import AppConfig


class DolaposcrumyConfig(AppConfig):
    name = 'dolaposcrumy'
