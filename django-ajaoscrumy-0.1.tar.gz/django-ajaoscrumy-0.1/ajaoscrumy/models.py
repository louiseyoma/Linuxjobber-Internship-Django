from django.db import models
from django.conf import settings
from django.shortcuts import reverse

# Create your models here.


class User(models.Model):
    ROLES = (
        ('1', 'Owner'),
        ('2', 'Admin'),
        ('3', 'Quality Analyst'),
        ('4', 'Developer')
    )

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    full_name = models.CharField(max_length=50)
    email = models.EmailField(help_text='Enter your email address')
    roles = models.CharField(choices=ROLES, max_length=1)

    class Meta:
        verbose_name_plural = 'users'
        verbose_name = 'user'

    def __str__(self):
        return self.full_name


class Goal(models.Model):
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='goals')
    title = models.CharField(max_length=50, help_text='Enter goal title')
    description = models.TextField(max_length=200, help_text='Enter goal description')
    created_date = models.DateField(auto_now=True)
    end_date = models.DateField()
    status = models.ForeignKey(Status, on_delete=models.CASCADE,)

    class Meta:
        verbose_name_plural = 'goals'

    def __str__(self):
        return self.title

    # def get_absolute_url(self):
    # return reverse('list_of_goals')


class Status(models.Model):
    STATUS = (
        ('WG', 'Weekly Goal'),
        ('DT', 'Daily Task'),
        ('VE', 'Verified'),
        ('DO', 'Done')
    )

    types_of_status = models.CharField(max_length=2, choices=STATUS, default='DT')

    class Meta:
        verbose_name_plural = 'status'


class Task(models.Model):
    goal = models.ForeignKey(Goal, on_delete=models.CASCADE, related_name='tasks')
    title = models.CharField(max_length=50, help_text='Enter Title')
    description = models.TextField(max_length=500, help_text='Enter description')
    created_date = models.DateField(auto_now=True)
    end_date = models.DateField(blank=True)
    assigned_to = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='')
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='')
    status = models.OneToOneField(Status, on_delete=models.CASCADE)
    completed = models.BooleanField(default=False)
    verified_by = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='')

    def __str__(self):
        return self.title

    class Meta:
        verbose_name_plural = 'tasks'
        verbose_name = 'task'