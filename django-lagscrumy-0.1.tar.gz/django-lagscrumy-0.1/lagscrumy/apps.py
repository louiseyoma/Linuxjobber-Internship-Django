from django.apps import AppConfig


class LagscrumyConfig(AppConfig):
    name = 'lagscrumy.app.lagscrumyconfig'
