This app creates django view using MYSQL
