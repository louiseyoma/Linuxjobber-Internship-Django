from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse
from django.http import Http404
from .models import User,TaskId
# Create your views here.

def homepage(request):
    #goals = TaskId.objects.get(pk=1)
    #context = {'goals' : goals}
    #template = loader.get_template ('linuxapp/home.html')
    #return HttpResponse(template.render(context, request))
    try:
      users = TaskId.objects.get(pk=5)
    except TaskId.DoesNotExist:
        raise Http404("user does not exist")
    return render(request, "linuxapp/home.html", {"users": users})

def home(request):
    a = TaskId.objects.all().filter(task_category='daily goals')
    return HttpResponse(a)

def addTask(request,usersView):
    return HttpResponse("Hello %s please edit or add a new task" % usersView ) 

def addUser(request):
    user = User(userName = 'mike')
    user.save()
    users = User.objects.all()
    output = ', '.join([eachuser.userName for eachuser in users])
    return HttpResponse(output)


   


