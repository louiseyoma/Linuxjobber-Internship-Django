from django.db import models
from django.utils import timezone


class ScrumyUser(models.Model):
    ROLES = (
    ('ONR', 'Owner'),
    ('ADM', 'Admin'),
    ('QTA', 'Quality Analyst'),
    ('DEV', 'Developer'),
)
    name = models.CharField(max_length=150)
    email = models.EmailField(max_length=200)
    username = models.CharField(max_length=100, unique = True)
    password = models.CharField(max_length=15, blank = False)
    role = models.CharField(max_length=3, choices = ROLES, blank = False)

    class Meta:
        verbose_name_plural = 'Scrumy User'

    def __str__(self):
        return self.name

    def getweeklygoals(self):
        return self.scrumygoals_set.all()
        # return self.scrumygoals_set.filter(status_id = 1)

# class GoalStatus(models.Model):
#     status = (
#         ('DT', 'Daily task'),
#         ('WT', 'Weekly task'),
#         ('V', 'Verified'),
#         ('D', 'Done'),
#     )
    
#     taskStatus = models.CharField(max_length=7, choices=status)
#     completed_date = models.DateField(null = False)

class GoalStatus(models.Model):
    name = models.CharField(max_length = 50)

    class Meta:
        verbose_name_plural = 'Goal Status'

    def __str__(self):
        return self.name

class ScrumyGoals(models.Model):
    user_id = models.ForeignKey('ScrumyUser', on_delete=models.CASCADE)
    goal_status = models.ForeignKey('GoalStatus', on_delete=models.CASCADE)
    goals = models.TextField()
    task_id = models.IntegerField(default=400)
    status_time = models.DateTimeField(timezone.now)
    

    class Meta:
        verbose_name_plural = 'Scrumy Goals'
        permissions = (("anywhere_to_anywhere", "Can move from anywhere to anywhere"), ("DT_to_verified", "Can move from DT to Verified"), ("verified_to_done", "Can move from verify to Done"), ("WG_to_DT", "Can move from WG to DT"))

    def __str__(self):
        return self.goals



