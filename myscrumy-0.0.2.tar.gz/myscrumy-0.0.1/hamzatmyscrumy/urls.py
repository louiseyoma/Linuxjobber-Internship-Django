from django.urls import path, re_path
from . import views


from django.contrib.auth import login
from django.contrib.auth import login



urlpatterns = [
    path('index/',views.Index,name="index"),
    path('task/<int:task_id>/',views.Move_goal,name="move_goal"),
    path('add_user/',views.Add_user,name="add_user"),
    path('goal/',views.Goal.as_view(),name="goal"),


]