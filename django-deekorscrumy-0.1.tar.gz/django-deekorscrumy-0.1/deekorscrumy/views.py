from django.shortcuts import render
from django.http import HttpResponse
from django.views import generic
from .forms import RegistrationForm
# from django.views.generic.edit import CreateView
from .models import ScrumyUser, ScrumyGoals, GoalStatus

# Create your views here.

# def index(request):
#     return HttpResponse("<h1> Welcome to my page</h1>")

def index(request):
    goals = ScrumyGoals.objects.all()
    newGoals = ScrumyGoals.objects.filter(goalStat=2)
    html = "<h1>Hello, world. You're at my homepage.</h1>"
    html += "<h2> All goals </h2>"
    html += "<table><tr><td>User</td><td>Goal</td><td>Description</td><td>Date</td><td>Time</td><td>Goal Status</td></tr>"

    for goal in goals:
        html +="<tr><td>"+ str(goal.user) +"</td><td>"+goal.goalName+"</td><td>"+goal.desc+"</td><td>"+ str(goal.date) +"</td><td>"+ str(goal.time)+ "</td><td>"+str(goal.goalStat)+"</td></tr></table>"

    for newgoal in newGoals:
        html +="<tr><td>"+ str(newgoal.user) +"</td><td>"+newgoal.goalName+"</td><td>"+newgoal.desc+"</td><td>"+ str(newgoal.date) +"</td><td>"+ str(newgoal.time)+ "</td><td>"+str(newgoal.goalStat)+"</td></tr></table>"

    return HttpResponse(html)

def move_goal(request, task_id):
    urlgoals = ScrumyGoals.objects.filter(id=task_id)
    for urlgoal in urlgoals:
        html = "<h1> This is the goal you wanted to see.</h1>"
        html += "<table><tr><td>User</td><td>Goal</td><td>Description</td><td>Date</td><td>Time</td><td>Goal Status</td></tr>"
        html += "<tr><td>"+ str(urlgoal.user) +"</td><td>"+urlgoal.goalName+"</td><td>"+urlgoal.desc+"</td><td>"+ str(urlgoal.date) +"</td><td>"+ str(urlgoal.time)+ "</td><td>"+str(urlgoal.goalStat)+"</td></tr></table>"

    return HttpResponse(html)
def add_user(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)

        if form.is_valid():
            name = request.POST.get('name','')
            email = request.POST.get('email','')
            roles = request.POST.get('roles','')

        user = ScrumyUser(name=name, email=email, roles=roles)
        user.save()

        form = RegistrationForm()

        return render(request, 'deekorscrumy/register.html', {'form': form})
    else:
        form = RegistrationForm()
        return render(request, 'deekorscrumy/register.html', {'form': form})

class UsersIndex(generic.ListView):

    context_object_name = 'users_list'
    template_name = 'deekorscrumy/users.html'

    def get_queryset(self):
        return ScrumyUser.objects.all()

def show_users(request):
    users = ScrumyUser.objects.all()
    # output = ', '.join([user.name for user in users])
    html = '<h1>All Users</h1>'
    for user in users:
        html += '<h3>'+ user.name +'</h3><h4>'+ user.email +'</h4>' 

    return HttpResponse(html)