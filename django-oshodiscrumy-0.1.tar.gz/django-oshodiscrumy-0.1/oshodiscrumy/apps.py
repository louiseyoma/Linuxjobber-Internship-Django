from django.apps import AppConfig


class OshodiscrumyConfig(AppConfig):
    name = 'oshodiscrumy'
