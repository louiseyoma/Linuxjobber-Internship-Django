=====
myapp
=====

sasoriscrummy is a simple django app to manage technical teams.
You can register a user and assign a role, also create task and assign 
tasks target and monitor the progress of the task and verify if task is 
completed.

Quick Start
-----------

1. Add "myapp" to your INSTALLED_APPS setting like this::

	INSTALLED_APPS = [
		---
		'myapp',
	]

2. Include the myapp URLconf in your project urls.py like this::

	path('myapp/', include(myapp.urls)),

3. Run python manage.py migrate to create the myapp models

4. Start the development server and visit http://127.0.0.1:8000/admin/
to create a myapp(you'll need the Admin app enabled) 

5. Visit http://127.0.0.1:8000/myapp to view the scrummy app	