from django.shortcuts import render, redirect
from django.template import loader
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.http import Http404
from .models import UserName,TaskId,Taskcategory
from linuxapp.forms import newUser,newTask
# Create your views here.

def homepage(request):
    try:
      users = TaskId.objects.all()


    except TaskId.DoesNotExist:
        raise Http404("user does not exist")
    return render(request, "linuxapp/home.html", {"users": users})


def addTask(request):
    if request.method == "POST":
        form = newTask(request.POST)
        if form.is_valid():
            model_instance = form.save(commit=False)
            model_instance.save()
            return redirect('homepage')
    else:
        
        form = newTask()
        return render(request,"linuxapp/addTask.html",{'form': form})


def addUser(request):
   
    if request.method == "POST":
        form = newUser(request.POST)
        if form.is_valid():
            model_instance = form.save(commit=False)
            model_instance.save()
            return redirect('homepage')
    else:
        
        form = newUser()
        return render(request,"linuxapp/addUser.html",{'form': form})


def login(request):
    template = loader.get_template('linuxapp/login.html')
    return HttpResponse(template.render(context, request))

def redirect(request):
    template = loader.get_template('linuxapp/redirect.html')
    return HttpResponse(template.render())

def move(request,pk):
    post = TaskId.objects.get(pk = pk)
    if request.method == "POST":
        form = newTask(request.POST, instance=post)
        if form.is_valid():
            model_instance = form.save(commit=False)
            model_instance.save()
            return redirect('homepage')
    else:
        form = newTask(instance=post)
        return render(request,"linuxapp/addTask.html",{'form': form})


