from django.forms import ModelForm
from linuxapp.models import UserName,TaskId,Taskcategory


class newUser(ModelForm):
    class Meta:
        model = UserName
        fields =['userName']

class newTask(ModelForm):
    class Meta:
        model = TaskId
        fields = ['task','task_category','task_id','user_id']