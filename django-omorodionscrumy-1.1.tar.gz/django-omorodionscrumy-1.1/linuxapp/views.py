from django.shortcuts import render,redirect
from django.template import loader
from django.http import HttpResponse,Http404
from .models import UserName,TaskId,Taskcategory
from linuxapp.forms import newUser,newTask
from django.contrib.auth.models import Group
from django.contrib.auth.decorators import login_required
# Create your views here.

@login_required
def homepage(request):
    try:
      users = TaskId.objects.all()   
    except TaskId.DoesNotExist:
        raise Http404("user does not exist")
    return render(request, "linuxapp/home.html", {"users": users})

@login_required
def addTask(request):
    if request.method == "POST":
        form = newTask(request.POST)
        if form.is_valid():
            model_instance = form.save(commit=False)
            model_instance.save()
            return redirect('/homepage')
    else:
        
        form = newTask()
        return render(request,"linuxapp/addTask.html",{'form': form})

@login_required
def addUser(request):
   
    if request.method == "POST":
        form = newUser(request.POST)
        if form.is_valid():
            model_instance = form.save(commit=False)
            model_instance.save()
            return redirect('/homepage')
            
    else:
        
        form = newUser()
        return render(request,"linuxapp/addUser.html",{'form': form})


def login(request):
    template = loader.get_template('linuxapp/login.html')
    return HttpResponse(template.render(context, request))


"""@login_required
def move(request,pk):
    post = TaskId.objects.get(pk = pk)
    if request.method == "POST":
        current_user = request.user
        Regular = Group.objects.get(pk=2)
        current_user_group = Group.objects.get(user= current_user)
        form = editTask(request.POST, instance=post)
        if form.is_valid():
            
            if form.cleaned_data.get('task_category') == 'Verify':
                return HttpResponse("Hello")
            
                if current_user_group.pk == Regular.pk:
                    return render(request,"linuxapp/no_permission.html")
                else:
                            
                    model_instance = form.save(commit=False)
                    if request.POST.get('task_category') == 'Verify':
                        return HttpResponse("Hello")

                    else:
                        return HttpResponse("Not Working")
                    #model_instance.save()
                    return redirect('/homepage')
            else:
                return HttpResponse("Naay")
    else:
        form = editTask(instance=post)
        return render(request,"linuxapp/editTask.html",{'form':form})"""

@login_required
def move (request,pk):
    if request.method == "POST":
        active_user = request.user
        active_user_group = Group.objects.get(user= active_user)
        task = TaskId.objects.get(pk=pk)

        if request.POST.get("task_category") == "Weekly Goal":
            task.task_category_id = 1
            task.save()
            return redirect('/homepage')

        elif request.POST.get("task_category") == "Daily Goal":
            task.task_category_id = 2
            task.save()
            return redirect('/homepage')
        elif request.POST.get("task_category") == "Verify":
            Regular = Group.objects.get(pk=2)
            if  active_user_group.pk == Regular.pk:
                    return render(request,"linuxapp/no_permission.html")
            else:
                task.task_category_id = 3
                task.save()
                return redirect('/homepage')
        else:
            Regular = Group.objects.get(pk=2)
            if  active_user_group.pk == Regular.pk:
                    return render(request,"linuxapp/no_permission.html")
            else:
                task.task_category_id = 4
                task.save()
                return redirect('/homepage')
    else:
        return render(request,"linuxapp/editTask.html")
    
    