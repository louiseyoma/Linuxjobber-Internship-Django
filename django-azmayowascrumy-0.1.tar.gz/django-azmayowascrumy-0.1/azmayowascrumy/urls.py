from django.urls import path

from azmayowascrumy.views import GoalsView
from . import views
app_name='azmayowascrumy'
urlpatterns=[
    # /
    path('',views.index,name='index'),
    path('add_user',views.add_user,name='add-user'),
    path('logout/',views.logout_user,name='logout'),
    path('add_goal',views.add_goal,name='add-goal'),
    path('goals/',views.goal_list,name='goal-index'),
    path('all_goals/',GoalsView.as_view(),name='goal-view'),
    path('login/',views.login_user,name='login'),
    path('goals/<int:goal_id>',views.goal_detail,name='goal-detail'),
    path('goals/<int:goal_id>/move',views.move_goal,name='move-goal'),
    path('goals/<int:goal_id>/tasks', views.tasks_list, name='task-index'),
    path('goals/<int:goal_id>/tasks/<int:task_id>', views.task_detail, name='task-detail'),
]