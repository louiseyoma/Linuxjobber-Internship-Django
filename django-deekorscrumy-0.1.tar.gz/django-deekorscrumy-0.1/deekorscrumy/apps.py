from django.apps import AppConfig


class DeekorscrumyConfig(AppConfig):
    name = 'deekorscrumy'
