from django.contrib import admin

# Register your models here.
from .models import Questions, Results, AppUsers, Questionaires, UserResult


admin.site.register(Questions)
admin.site.register(Results)
admin.site.register(AppUsers)
admin.site.register(Questionaires)
admin.site.register(UserResult)
