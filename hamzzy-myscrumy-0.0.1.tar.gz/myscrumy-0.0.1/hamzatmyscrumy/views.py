from django.shortcuts import render
from django.http import HttpResponse
from .models import GoalStatus,ScrumyGoals,ScrumyUser

# Create your views here.

def Index(request):
    target=GoalStatus.objects.filter(daily_target='to finish the task',status=1)
    for n in target:
        pass
    ta=[  n.status , n.daily_target , n.weekly_target]
    return HttpResponse(ta)

def Move_goal(request,task_id):
    task=ScrumyGoals.objects.get(id=task_id)

    return HttpResponse({task.task,task.description})



def Add_user(request):
    add=ScrumyUser.objectss.create(username='john',first_name='doe',last_name='cex',password='',role='admin')
    add.save()
    user=ScrumyUser.objects.all()
    #x=[x for x in user]
    for n in user:
       pass
    return HttpResponse(n.username)

