from django.urls import path
from . import views

urlpatterns = [
    path('',  views.homepage, name = 'homepage'),
    path('home/', views.home, name='home'),
    path('task/<str:usersView>/', views.addTask, name='addTask'),
    path('user/adduser/', views.addUser, name='addUser'),
    path('user/viewTable/', views.table, name='viewTable'),
    path('user/finduser/<str:username>/', views.findUser, name='findUser'),
]