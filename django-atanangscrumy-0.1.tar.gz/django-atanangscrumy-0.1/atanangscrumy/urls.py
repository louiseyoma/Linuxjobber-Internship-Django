from django.conf.urls import url
from yoursurnamescrummy import views

urlpatterns = [
    url(r'^$',views.homepage, name='homepage')
]
