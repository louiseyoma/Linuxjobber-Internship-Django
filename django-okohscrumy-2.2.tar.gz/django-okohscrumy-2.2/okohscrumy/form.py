from django import forms
from .models import ScrumyUser

class UserForm(forms.ModelForm):
    username = forms.CharField(label='Enter Username', max_length=100)
    email = forms.CharField(label='Enter Email', max_length=100)
    role = forms.CharField(label='Enter User Role', max_length=100)

    class Meta:
        model = ScrumyUser
        fields = ('username', 'email', 'role')