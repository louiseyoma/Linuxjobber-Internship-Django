from django.conf.urls import url
from atanangscrumy import views
from django.urls import include, path

urlpatterns = [
    # url(r'^$', views.homepage, name='homepage'),
    path('atanangscrumy/<str:usersView>/', views.addTask, name='addtask'),
    # url(r'^$', views.homepage, name='homepage'),
    url('atanangscrumy/homepage', views.homepage, name='homepage')

]
