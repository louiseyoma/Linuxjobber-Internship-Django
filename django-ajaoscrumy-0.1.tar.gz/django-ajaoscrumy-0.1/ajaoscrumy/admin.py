from django.contrib import admin
from .models import ScrumyGoals, ScrumyUser

# Register your models here.

class ScrumyGoalsAdmin(admin.ModelAdmin):
    list_display = ('goal',)


admin.site.register(ScrumyGoals, ScrumyGoalsAdmin)


class ScrumyUserAdmin(admin.ModelAdmin):
    list_display = ('age',)


admin.site.register(ScrumyUser, ScrumyUserAdmin)