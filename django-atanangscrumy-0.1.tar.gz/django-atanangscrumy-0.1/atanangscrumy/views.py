from django.shortcuts import render
from django.http import HttpResponse
from .models import ScrumyGoals, ScrumyUser


# Create your views here.


def homepage(request):
    a = ScrumyGoals.objects.all().filter(task_category='daily goals')
    return HttpResponse(a)


def addTask(request,usersView):
    return HttpResponse("Hello %s please edit or add a new task" % usersView)

def addUser(request):
    user = ScrumyUser(userName = 'mike')
    user.save()
    users = ScrumyUser.objects.all()
    output = ', '.join([eachuser.userName for eachuser in users])
    return HttpResponse(output)

def home(request):
    Scrumy_goals = ScrumyGoals.objects.order_by('user_id')
    goals_dict = {'scrumy_records': Scrumy_goals}
    return render(request, 'atanangscrumy/home.html', context=goals_dict)
