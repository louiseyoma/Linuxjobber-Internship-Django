from django.apps import AppConfig


class AjaoscrumyConfig(AppConfig):
    name = 'ajaoscrumy'
