from django.apps import AppConfig


class OkoroscrumyConfig(AppConfig):
    name = 'okoroscrumy'
