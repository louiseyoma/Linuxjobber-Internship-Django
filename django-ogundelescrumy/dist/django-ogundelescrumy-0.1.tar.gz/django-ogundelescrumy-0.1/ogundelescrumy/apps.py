from django.apps import AppConfig


class OgundelescrumyConfig(AppConfig):
    name = 'ogundelescrumy'
