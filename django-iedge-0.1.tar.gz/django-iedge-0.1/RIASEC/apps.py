from django.apps import AppConfig


class RiasecConfig(AppConfig):
    name = 'RIASEC'
