from django.urls import path
from . import views


urlpatterns = [
  path('', views.index, name='index'),
  path('add_task/', views.add_task, name='add_task'),
  path('move_goal/', views.move_goal, name='move_goal'),
  path('add_user/', views.add_user, name='add_user'),
]

handler404 = 'emmascrumy.views.handler404'
handler500 = 'emmascrumy.views.handler500'