function showMenu() {

}