from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import get_object_or_404, get_list_or_404, render
from .models import ScrumyGoals, ScrumyUser, GoalStatus
from .forms import UserForm

def index(request):
    scrumygoals = ScrumyGoals.objects.filter(status_id=2)
    return HttpResponse(scrumygoals)


def move_goal(request, task_id):
    goal = ScrumyGoals.objects.get(pk=task_id)
    return HttpResponse(goal)

def user_list(request):
        user = ScrumyUser.objects.all()
        output = ', '.join([p.userName for p in user])
        return HttpResponse(output)


def add_user(request):
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            form.save()
            
            return HttpResponseRedirect('/user-list')

    else:
        form = UserForm()

    return render(request, 'add_user.html', {'form': form})


