from django.contrib import admin
from django.contrib.auth.models import Permission

from .models import get_models

# Register your models here.
for model in get_models():
    admin.site.register(model)

admin.site.register(Permission)