from django.contrib import admin

# Register your models here.
from.models import ScrumyGoals, ScrumyUser
 
admin.site.register(ScrumyUser)
admin.site.register(ScrumyGoals)
