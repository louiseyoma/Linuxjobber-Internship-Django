from django.shortcuts import render
from django.http import HttpResponse
from .models import ScrumyGoals, ScrumyUser
from django.http import Http404

def homepage(request):
 a = ScrumyGoals.objects.all().filter(task_category='daily goals')
 return HttpResponse(a)

def addTask(request,usersView):
    return HttpResponse("Hello %s please edit or add a new task" % usersView ) 

def addUser(request):
 user = ScrumyUser(userName = 'mike')
 user.save()
 users = ScrumyUser.objects.all()
 output = ''.join([eachuser.userName for eachuser in users])
 return HttpResponse(output)    


def index():
	try:
		user = ScrumyUser.objects.get(pk = 1)
	except ScrumyUser.DoesNotExist:
		raise Http404("User does not exist")
		return render(request, "live/users.html",{"user":user})

 


#create your views here