from django.apps import AppConfig


class OkohscrumyConfig(AppConfig):
    name = 'okohscrumy'
