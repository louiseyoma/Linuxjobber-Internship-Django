from django.db import models


class Taskcategory(models.Model):
    
	status_name = models.CharField(max_length=50)

	def __str__(self):
		return self.status_name




class UserName(models.Model):
	userName = models.CharField(max_length=100)
	password = models.CharField(max_length=100, default="linuxjobber")

	def __str__(self):
		return self.userName
		

class TaskId(models.Model):
	user_id = models.ForeignKey(UserName, on_delete = models.CASCADE)
	task = models.TextField()
	task_id = models.IntegerField(default=700, null=False) # changed from charfield and null from true
	task_category = models.ForeignKey(Taskcategory, on_delete = models.PROTECT, null=False, default=700)
	move_task = models.IntegerField(default=123, null=False)

	def __str__(self):
		return self.task