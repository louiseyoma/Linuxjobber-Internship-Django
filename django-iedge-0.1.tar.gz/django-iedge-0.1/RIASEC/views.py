from django.shortcuts import render, redirect
from django.views import generic
from django.db import models
from django.http import HttpResponse
from .models import Questions, Results, Questionaires,UserResult, AppUsers
from django.contrib.auth.models import User
from .forms import AppUsersForm, ContactUsForm
from django.contrib.auth import authenticate, login
from django.core.exceptions import ObjectDoesNotExist


# Create your views here.

def result(request):
	user = request.user
	
	try:
		get_user = AppUsers.objects.get(username = user)
		resulting = get_user.userresult_set.get(app_user=get_user.id)

	except ObjectDoesNotExist as e:
		return redirect('questionaire')

	context ={
			'user':	user,
			'get_user': get_user,
			'resulting': resulting
			}	
	return render(request, 'riasec/result.html', context)


def index(request):
	welcome = "Welcome"
	context = {
		'welcome': welcome
	}

	return render(request, 'riasec/index.html', context)


def contact_us(request):
	if request.method == 'POST':
		form = ContactUsForm(request.POST)
		if form.is_valid():
			fs= form.save(commit=False)
			fs.full_name = request.POST['full_name']
			fs.save()
			return redirect(index)
		else:
			return HttpResponse('gggcg')

	else:
		form = ContactUsForm()
	context = {
		'form': form,
	}		
	return render(request, 'riasec/contact.html', context)
	


class Questions(generic.ListView):

	template_name = 'riasec/questionaire.html'

	context_object_name = 'questionaire_object'

	def get_queryset(self):

		return Questions.objects.all()



def Questionaire(request):
	total_realistic = 0
	total_investigative = 0
	total_artistic = 0
	total_social = 0
	total_enterprising = 0
	total_conventional = 0
	user = request.user

	if request.method == 'POST':

		realistic = Questionaires.objects.filter(question_group = 'R')
		for r in realistic:
			if request.POST['choice' + str(r.id)] == 'Yes':
				total_realistic+=1

		investigative = Questionaires.objects.filter(question_group = 'I')
		for i in investigative:
			if request.POST['choice' + str(i.id)] == 'Yes':
				total_investigative+=1

		artistic = Questionaires.objects.filter(question_group = 'A')
		for a in artistic:
			if request.POST['choice' + str(a.id)] == 'Yes':
				total_artistic+=1

		social = Questionaires.objects.filter(question_group = 'S')
		for s in social:
			if request.POST['choice' + str(s.id)] == 'Yes':
				total_social+=1

		enterprising = Questionaires.objects.filter(question_group = 'E')
		for e in enterprising:
			if request.POST['choice' + str(e.id)] == 'Yes':
				total_enterprising+=1

		conventional = Questionaires.objects.filter(question_group = 'C')
		for c in conventional:
			if request.POST['choice' + str(c.id)] == 'Yes':
				total_conventional+=1


		evaluation = {
			'Realistic':total_realistic,
			'Investigative':total_investigative,
			'Artistic': total_artistic,
			'Social': total_social,
			'Enterprising': total_enterprising,
			'Conventional':total_conventional
			}

		max_result = max(evaluation, key = evaluation.get)
		resulting = Results.objects.get(name = max_result)
		get_user = AppUsers.objects.get(username = user)
		try:
			resulting_update = get_user.userresult_set.get(app_user=get_user.id)
			resulting_update.name = resulting.name
			resulting_update.preamble = resulting.preamble 
			resulting_update.major1 = resulting.major1
			resulting_update.major2 = resulting.major2
			resulting_update.major3 = resulting.major3
			resulting_update.major4 = resulting.major4
			resulting_update.major5 = resulting.major5
			resulting_update.major6 = resulting.major6
			resulting_update.major7 = resulting.major7
			resulting_update.related_pathway1 = resulting.related_pathway1
			resulting_update.related_pathway2 = resulting.related_pathway2
			resulting_update.related_pathway3 = resulting.related_pathway3
			resulting_update.related_pathway4 = resulting.related_pathway4
			resulting_update.app_user = AppUsers.objects.get(username=user)
			resulting_update.save()
			resulting = get_user.userresult_set.get(app_user=get_user.id)

			context = {
					'resulting': resulting
				}
			return render(request, 'riasec/result.html', context)

		except ObjectDoesNotExist as e:
				addUserResult = UserResult.objects.create(
						name = resulting.name,
						preamble = resulting.preamble, 
						major1 = resulting.major1,
						major2 = resulting.major2,
						major3 = resulting.major3,
						major4 = resulting.major4,
						major5 = resulting.major5,
						major6 = resulting.major6,
						major7 = resulting.major7,
						related_pathway1 = resulting.related_pathway1,
						related_pathway2 = resulting.related_pathway2,
						related_pathway3 = resulting.related_pathway3,
						related_pathway4 = resulting.related_pathway4,
						app_user = AppUsers.objects.get(username=user)
						)
				context = {
					'resulting': resulting
				}
				return render(request, 'riasec/result.html', context)

	else:
		questionaire = Questionaires.objects.all()
		context ={
			'questionaire': questionaire,
			}	
		return render(request, 'riasec/questionaire.html', context)




def signup(request):
    firstname=''
    lastname=''
    emailvalue=''
    uservalue=''
    passwordvalue1=''
    passwordvalue2=''

    form= AppUsersForm(request.POST or None)
    if form.is_valid():
        fs= form.save(commit=False)
        firstname= form.cleaned_data.get("first_name")
        lastname= form.cleaned_data.get("last_name")
        emailvalue= form.cleaned_data.get("email")
        uservalue= form.cleaned_data.get("username")
        passwordvalue1= form.cleaned_data.get("password1")
        passwordvalue2= form.cleaned_data.get("password2")

        if passwordvalue1 == passwordvalue2:
            try:
                user= User.objects.get(username=uservalue) #if able to get, user exists and must try another username
                context= {'form': form, 'error':'The username you entered has already been taken. Please try another username.'}
                return render(request, 'RIASEC/signup.html', context)
            except User.DoesNotExist:
            	user= User.objects.create_user(uservalue, password= passwordvalue1,email=emailvalue, is_staff= False)
            	user.first_name = firstname
            	user.last_name = lastname           	
            	user.save()

            	# addUser = AppUsers.objects.create(
            	# 	username
            	# 	first_name
            	# 	last_name
            	# 	password1
            	# 	password2
            	# 	email
            	# 	phone_no
            	# 	birthdate
            	# 	gender
            	# 	location
            	# 	)

            	user.save()

            	login(request,user)

            	fs.user= request.user

            	fs.save()

            	context= {'form': form}
            	return render(request, 'RIASEC/index.html', context)
            
        else:
            context= {'form': form, 'error':'The passwords that you provided don\'t match'}
            return render(request, 'RIASEC/signup.html', context)
        

    else:
        context= {'form': form}
        return render(request, 'RIASEC/signup.html', context)