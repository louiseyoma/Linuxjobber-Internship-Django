from django import forms
from .models import ScrumyUser,ScrumyGoal,ScrumyTask


class SignUpForm(forms.ModelForm):

    class Meta:
        model=ScrumyUser
        exclude=[]

class AddGoalForm(forms.ModelForm):
    class Meta:
        model=ScrumyGoal
        exclude=['completed_on','date_created','verified_by','verified_on']

class AddTaskForm(forms.ModelForm):
    class Meta:
        model=ScrumyTask
        exclude=['completed_on','date_created','verified_by','verified_on',
                 'assigned_by','assigned_on','updated_by','updated_on']

class ChangeGoalForm(forms.ModelForm):
    class Meta:
        model=ScrumyGoal
        fields=['status','goal_type']


