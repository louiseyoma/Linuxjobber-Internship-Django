from django.contrib import admin
from hammedscrumy.models import ScrumyUser, ScrumyGoal, ScrumyStatus


admin.site.register(ScrumyUser)
admin.site.register(ScrumyGoal)
admin.site.register(ScrumyStatus)

# Register your models here.
