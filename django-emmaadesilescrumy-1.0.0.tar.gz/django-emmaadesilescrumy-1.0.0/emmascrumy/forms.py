from django import forms
from .models import ScrumyUser, ScrumyGoals, GoalStatus

class AddNewUserForm(forms.ModelForm):
  class Meta:
    model = ScrumyUser
    fields = '__all__'

class AddTaskForm(forms.ModelForm):
  class Meta:
    model = ScrumyGoals
    fields = [
      "user_id",
      "status_id",
      "task_title",
      "task"
    ]

class ChangeTaskStatusForm(forms.ModelForm):
  model = GoalStatus
  exclude = ['created_at', 'updated_at']
  fields = '__all__'