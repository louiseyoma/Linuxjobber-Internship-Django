from django.db import models

# Create your models here.
class ScrummyUser(models.Model):
    name = models.CharField(max_length=200)
    email = models.CharField(max_length=200)
    roles = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class GoalStatus(models.Model):
    day_target = models.CharField(max_length=40)
    week_target = models.CharField(max_length=40)
    verify = models.CharField(max_length=40)
    done = models.CharField(max_length=40)

class ScrummyGoals(models.Model):
    user_name = models.ForeignKey(ScrummyUser, on_delete=models.CASCADE)
    goal_status = models.ForeignKey(GoalStatus, on_delete=models.CASCADE)
    task = models.CharField(max_length=200)
    task_target = models.CharField(max_length=30)
    date_created = models.DateTimeField(auto_now=True,blank="")
    date_updated = models.DateTimeField(auto_now=True,blank="")

    def __str__(self):
        return self.task
    def get_task_target(self):
        return self.task_target








