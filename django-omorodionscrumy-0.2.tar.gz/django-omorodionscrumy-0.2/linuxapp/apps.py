from django.apps import AppConfig


class LinuxappConfig(AppConfig):
    name = 'linuxapp'
