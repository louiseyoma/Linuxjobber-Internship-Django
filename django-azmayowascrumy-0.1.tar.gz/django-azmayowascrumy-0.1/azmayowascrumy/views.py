from django.contrib.auth import login, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib.auth.hashers import make_password, check_password
from django.core.exceptions import ObjectDoesNotExist
from django.http import Http404
from django.template.response import TemplateResponse
from django.utils import timezone
from django.shortcuts import render, HttpResponse, redirect, get_object_or_404
from django.views import generic

from azmayowascrumy.form import SignUpForm, AddGoalForm, ChangeGoalForm
from .models import ScrumyGoal, ScrumyUser, ScrumyTask


# Create your views here.

def show_error(request, message):
    return TemplateResponse(request, "azmayowascrumy/error_page.html", {"error_message": message})


@login_required
def index(request):
    return redirect("azmayowascrumy:goal-index")


def add_user(request):
    form = SignUpForm(request.POST or None)
    if request.method == "POST":
        user = ScrumyUser()
        form = SignUpForm(request.POST, instance=user)
        if form.is_valid():
            new_user = form.save(commit=False)
            new_user.save()
            new_user.set_password(user.password)
            new_user.save()

            return HttpResponse("Saved")
        else:
            return TemplateResponse(request, 'azmayowascrumy/signup-form.html', {"form": form})
    else:
        return TemplateResponse(request, 'azmayowascrumy/signup-form.html', {"form": form})


# Goal Methods

def goal_list(request):
    goals = []
    g = {}
    for user in ScrumyUser.objects.all():
        user_goal = user.scrumygoal_set.all()
        goals.append(user_goal)
        g.update({user.username: user_goal})
    ctx = {"goals": goals}
    return TemplateResponse(request, "azmayowascrumy/index.html", ctx)


class GoalsView(generic.ListView):
    template_name = 'azmayowascrumy/generic.html'
    context_object_name = 'goal_list'
    queryset = ScrumyGoal.objects.all()


def add_goal(request):
    error_message = ""
    form = AddGoalForm(request.POST or None)
    if request.method == "POST":
        goal = ScrumyGoal()
        form = AddGoalForm(request.POST, instance=goal)
        if form.is_valid():
            form.scrumy_user = get_object_or_404(ScrumyUser, username=request.user)
            form.save()
        else:
            return TemplateResponse(request, "azmayowascrumy/add-goal.html", {"form": form})
    else:
        return TemplateResponse(request, "azmayowascrumy/add-goal.html", {"form": form})


def move_goal(request, goal_id):
    goal = get_object_or_404(ScrumyGoal, pk=goal_id)
    form = ChangeGoalForm(request.POST or None, instance=goal)
    if request.method == "POST":
        if form.is_valid():
            form.save()
            return HttpResponse("Saved")
        else:
            return HttpResponse("Error in form")
    else:
        return TemplateResponse(request, "azmayowascrumy/move_goal.html", {"form": form})


# Task methods
def tasks_list(request):
    tasks = ScrumyTask.objects.all()
    return HttpResponse(tasks)


def task_detail(request, task_id):
    return HttpResponse()


def add_task(request, goal_id):
    form = AddGoalForm(request.POST or None)
    if request.user.is_authenticated:
        if request.method == "POST":
            task = ScrumyTask()
            form = AddGoalForm(request.POST, instance=task)
            if form.is_valid():
                new_task = form.save(commit=False)
                new_task.save()

            else:
                return HttpResponse(form)
        else:
            return HttpResponse(form)
    else:
        return HttpResponse("Please log in")


def login_user(request):
    error_message = ""
    if request.user.is_authenticated:
        return redirect("azmayowascrumy:goal-index")
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        try:

            user = ScrumyUser.objects.get(username=username)
            if check_password(password, user.password):
                user=authenticate(username=username,password=password)
                login(request,user)
            else:
                error_message = "Invalid Password"
        except ScrumyUser.DoesNotExist:
            error_message = "Sorry, No account exists with the username"

        finally:
            if error_message:
                return TemplateResponse(request, "registration/login.html", {"error_message": error_message})
            return redirect("azmayowascrumy:goal-index")
    else:
        return TemplateResponse(request, "registration/login.html", {"error_message": error_message})


def goal_detail(request):
    return None
