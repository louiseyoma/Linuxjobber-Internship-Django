from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import TemplateView
from django.views import generic
from .models import ScrumyGoals
from .models import ScrumyUser
from .form import UserForm

# Create your views here.
# def index(request):
#     return HttpResponse("Hello World")

def index(request):
    records = ScrumyGoals.objects.all().order_by('-date_created')
    output = ', '.join([q.task for q in records])
    return HttpResponse(output)

def move_goal(request, task_id):
    goals = ScrumyGoals.objects.get(pk=task_id)
    return HttpResponse(goals)

#def add_user(request):
    # all_users = ScrumyUser.all()
    # html = ''
    # for user in all_users:
    #     html += '' + user.username + '<br>'
    # return HttpResponse(html)


class add_user(TemplateView):
    def get(self, request):
        form = UserForm()
        goals = ScrumyUser.objects.all()
        return render(request, 'okohscrumy/add_user.html', {'form': form, 'goals': goals})

    def post(self, request):
        username = None
        email = None
        role = None
        success = None
        form = UserForm(request.POST or None)
        if form.is_valid():
            success = 'Successful'
            form.save()

            username = form.cleaned_data['username']
            email = form.cleaned_data['email']
            role = form.cleaned_data['role']

            form = UserForm()
        goals = ScrumyUser.objects.all()
        args = {'form': form, 'username': username, 'email': email, 'role': role, 'goals': goals, 'success': success}
        return render(request, 'okohscrumy/add_user.html', args)