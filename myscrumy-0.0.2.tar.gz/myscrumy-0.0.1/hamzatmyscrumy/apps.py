from django.apps import AppConfig


class HamzatmyscrumyConfig(AppConfig):
    name = 'hamzatmyscrumy'
