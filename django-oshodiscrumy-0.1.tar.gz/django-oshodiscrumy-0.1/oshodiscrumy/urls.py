from django.urls import path

from . import views


urlpatterns = [
    path('', views.IndexView.as_view(), name = 'index'),
    path('users/', views.users, name = 'users'),
    path('move/<task_id>/', views.move_task, name = 'move_task'),
    path('add_user/', views.add_user, name = 'add_user'),
    path('add_task/', views.add_task, name = 'add_task'),
    path('view_goal/', views.goals_view.as_view(), name = 'view_goals'),
    # path('<int:goal_id>/changestatus/', views.change_task_status, name = 'change_task_status'),
]