from django.apps import AppConfig


class UgwuezescrumyConfig(AppConfig):
    name = 'ugwuezescrumy'
