from django.urls import path

from . import views

app_name = 'okohscrumy'
urlpatterns = [
    path('', views.indexView.as_view(), name='index'),
    path('<int:user_id>/', views.error_page, name='error_page'),
    path('add_user/', views.add_user.as_view(), name='add_user'),
    path('add_tasks/', views.add_tasks, name='add_tasks'),
    path('move_task/',views.move_task, name="move_task"),
]

