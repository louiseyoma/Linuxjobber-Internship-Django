from django.contrib import admin
from .models import GoalStatus,ScrumyGoals,ScrumyUser



admin.site.register(GoalStatus)

admin.site.register(ScrumyGoals)

admin.site.register(ScrumyUser)

