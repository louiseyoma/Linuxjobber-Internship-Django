from . import views 
from django.conf.urls import url
from django.contrib.auth.decorators import login_required,permission_required,user_passes_test

urlpatterns = [
    url(r'^$', views.index, name = 'home'),
    url(r'^contact$', views.contact_us, name = 'contact_us'),
    url(r'^result$', views.result, name = 'result'),
    url(r'^questionaire$', views.Questionaire, name = 'questionaire'),    
    url(r'^signup/$', views.signup,  name = 'signup'),
   ]