from django.contrib import admin
from .models import ScrumyUser, GoalStatus, ScrumyGoals

# Register your models here.
class ScrumyUserAdmin(admin.ModelAdmin):
    pass

class GoalStatusAdmin(admin.ModelAdmin):
    pass

class ScrumyGoalsAdmin(admin.ModelAdmin):
    pass


admin.site.register (ScrumyUser, ScrumyUserAdmin)
admin.site.register (GoalStatus, GoalStatusAdmin)
admin.site.register (ScrumyGoals, ScrumyGoalsAdmin)
