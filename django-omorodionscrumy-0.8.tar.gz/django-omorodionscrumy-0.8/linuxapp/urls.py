
from django.urls import path
from . import views
urlpatterns = [
    path('',views.homepage, name='homepage'),
    path('home',views.home, name='home'),
    #path('linuxapp/<str:usersView>/', views.addTask, name = 'addTask'),
    path('linuxapp/user/new', views.addUser, name = 'addUser'),   
]


