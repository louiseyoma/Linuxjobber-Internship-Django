from django import forms

class RegistrationForm(forms.Form):
    name = forms.CharField(label="Name", max_length=100)
    email = forms.CharField(label="Email", max_length=150)
    roles = forms.CharField(label="Roles", max_length=50)