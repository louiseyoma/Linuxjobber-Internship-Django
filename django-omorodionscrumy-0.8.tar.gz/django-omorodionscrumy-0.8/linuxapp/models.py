from django.db import models

# Create your models here.
class User(models.Model):
    userName = models.CharField(max_length=100)

    def __str__ (self):
        return self.userName

class TaskId(models.Model):
    user_id = models.ForeignKey(User, on_delete = models.CASCADE)
    task = models.TextField()
    task_category = models.CharField(max_length=20)

    def __str__(self):
         return self.task 