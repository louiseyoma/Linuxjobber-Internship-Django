from django.apps import AppConfig


class HussainscrumyConfig(AppConfig):
    name = 'hussainscrumy'
