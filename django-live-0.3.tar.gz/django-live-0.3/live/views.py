from django.shortcuts import render
from django.http import HttpResponse
from .models import ScrumyGoals, ScrumyUser

def homepage(request):
 a = ScrumyGoals.objects.all().filter(task_category='daily goals')
 return HttpResponse(a)

#create your views here