from django.contrib import admin
from .models import ScrumyUser, ScrumyGoals
# Register your models here.

admin.site.register(ScrumyUser)
admin.site.register(ScrumyGoals)
