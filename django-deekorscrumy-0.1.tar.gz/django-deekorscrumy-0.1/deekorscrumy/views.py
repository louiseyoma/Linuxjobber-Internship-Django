from django.shortcuts import render
from django.http import HttpResponse
from django.views import generic
from .forms import RegistrationForm, AddTasks
from django.core.exceptions import ObjectDoesNotExist
# from django.views.generic.edit import CreateView
from .models import ScrumyUser, ScrumyGoals, GoalStatus

# Create your views here.

# def index(request):
#     return HttpResponse("<h1> Welcome to my page</h1>")

def index(request):
    goals = ScrumyGoals.objects.all()
    newGoals = ScrumyGoals.objects.filter(goalStat=2)
    users = ScrumyUser.objects.all()
    all = ScrumyUser.objects.count()
    user_range = range(1, all)
    b = ''
    for serial_no in user_range:
        try: a = ScrumyUser.objects.get(id=2)
        except ObjectDoesNotExist: b += 'Range not found'
    context = {
        'users': users,
        'all' : all,
        'user_range' : user_range,
        'b' : b,
        'newGoals' : newGoals
    }
    return render(request, 'deekorscrumy/index.html', context)

def add_tasks(request):
    if request.method == 'POST':
        form = AddTasks(request.POST)

        if form.is_valid():
            goalName = request.POST.get('goalName','')
            desc = request.POST.get('desc','')
            date = request.POST.get('date','')
            time = request.POST.get('time','')

            task = ScrumyGoals(goalName=goalName, desc=desc, date=date, time=time)
            task.save()

        form = AddTasks()

        return render(request, 'deekorscrumy/add_task.html', {'form': form})
    else:
        form = AddTasks()
        return render(request, 'deekorscrumy/add_task.html', {'form': form})


def move_goal(request, task_id):
    urlgoals = ScrumyGoals.objects.filter(id=task_id)
    for urlgoal in urlgoals:
        html = "<h1> This is the goal you wanted to see.</h1>"
        html += "<table><tr><td>User</td><td>Goal</td><td>Description</td><td>Date</td><td>Time</td><td>Goal Status</td></tr>"
        html += "<tr><td>"+ str(urlgoal.user) +"</td><td>"+urlgoal.goalName+"</td><td>"+urlgoal.desc+"</td><td>"+ str(urlgoal.date) +"</td><td>"+ str(urlgoal.time)+ "</td><td>"+str(urlgoal.goalStat)+"</td></tr></table>"

    return HttpResponse(html)

def add_user(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)

        if form.is_valid():
            name = request.POST.get('name','')
            email = request.POST.get('email','')
            roles = request.POST.get('roles','')
            password = request.POST.get('password','')

        user = ScrumyUser(name=name, email=email, roles=roles, password=password)
        user.save()

        form = RegistrationForm()

        return render(request, 'deekorscrumy/add_user.html', {'form': form})
    else:
        form = RegistrationForm()
        return render(request, 'deekorscrumy/add_user.html', {'form': form})

class UsersIndex(generic.ListView):

    context_object_name = 'users_list'
    template_name = 'deekorscrumy/users.html'

    def get_queryset(self):
        return ScrumyUser.objects.all()

def show_users(request):
    users = ScrumyUser.objects.all()
    # output = ', '.join([user.name for user in users])
    html = '<h1>All Users</h1>'
    for user in users:
        html += '<h3>'+ user.name +'</h3><h4>'+ user.email +'</h4>' 

    return HttpResponse(html)