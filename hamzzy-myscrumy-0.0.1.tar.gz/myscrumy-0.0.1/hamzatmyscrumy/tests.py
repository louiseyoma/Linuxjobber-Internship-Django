from django.test import TestCase
from django.urls import resolve
# Create your tests here.
from .views import Index

class RandomTest(TestCase):
    def test_b(self):
        self.assertEqual(1+1,2)
class IndexTest(TestCase):
    def test_home(self):
        found=resolve('index/')
        self.assertEqual(found.func,Index)

