
from django.urls import path
from . import views

app_name = 'linuxapp'

urlpatterns = [
    path('homepage/',views.homepage, name='homepage'),
    path('linuxapp/addTask/', views.addTask, name = 'addTask'),
    path('linuxapp/user/new/', views.addUser, name = 'addUser'),
    path('accounts/login', views.login , name='login'),
    path('accounts/login/redirect', views.redirect, name='redirect'),
    path('homepage/move/<int:pk>/', views.move , name='move'),
    #path('home', views.test, name= 'home'),
]


