ugwuezescrumy is a simple Django app to manage scrum task. for admin can add users
and each users will have their tasks

Quick start
-----------

1. Add "ugwuezescrumy" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'ugwuezescrumy',
    ]

2. Include the polls URLconf in your project urls.py like this::

    path('polls/', include('ugwuezescrumy.urls')),

3. Run `python manage.py migrate` to create the polls models.

4. Start the development server and visit http://127.0.0.1:8000/admin/
   to create a poll (you'll need the Admin app enabled).

5. Visit http://127.0.0.1:8000/home/ to view task.
6. Visit http://127.0.0.1:8000/home/id to view a task with a particular id
7. Visit http://127.0.0.1:8000/home/add_user to add a user and list of updated users