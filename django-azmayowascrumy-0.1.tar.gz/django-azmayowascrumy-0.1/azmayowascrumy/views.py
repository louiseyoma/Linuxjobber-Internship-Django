from django.contrib.auth.hashers import make_password
from django.template.response import TemplateResponse
from django.utils import timezone
from django.shortcuts import render, HttpResponse, redirect,get_object_or_404
from azmayowascrumy.form import SignUpForm,AddGoalForm
from .models import ScrumyGoal,ScrumyUser,ScrumyTask
# Create your views here.
def index(request):
    return redirect("azmayowascrumy:goal-index")

# def add_task(request,goal_id):
#     if request.user.is_authenticated:
#         if request.method == "POST":
#             user=ScrumyUser.objects.get(username=request.user)
#             notes=request.POST['notes']
#             assigned_to=request.POST['assigned_to']
#             assigned_by=request.POST['assigned_to']
#             assigned_on=timezone.now()
#             goal_type=request.POST['goal_type']
#             date_created=timezone.now()
#             date_updated=timezone.now()
#             ScrumyGoal.objects.create(user=user,title=title,description=description,
#                                       goal_type=goal_type,date_created=date_created,
#                                       date_updated=date_updated)
#             return HttpResponse()
#         else:
#             return HttpResponse()
#     else:
#         return HttpResponse("Please Login")
# def add_goal(request):
#     if request.user.is_authenticated:
#         if request.method == "POST":
#             user=ScrumyUser.objects.get(username=request.user)
#             title=request.POST['title']
#             description=request.POST['description']
#             goal_type=request.POST['goal_type']
#             date_created=timezone.now()
#             date_updated=timezone.now()
#             ScrumyGoal.objects.create(user=user,title=title,description=description,
#                                       goal_type=goal_type,date_created=date_created,
#                                       date_updated=date_updated)
#             return HttpResponse()
#         else:
#             return HttpResponse()
#     else:
#         return HttpResponse("Please Login")


def add_user(request):
    form=SignUpForm(request.POST or None)
    if request.method == "POST":
        user = ScrumyUser()
        form = SignUpForm(request.POST, instance=user)
        if form.is_valid():
            new_user=form.save(commit=False)
            new_user.password=make_password(form.cleaned_data['password'])
            new_user.save()
            return HttpResponse("Saved")
        else:
            return TemplateResponse(request, 'azmayowascrumy/signup-form.html', {"form": form})
    else:
        return TemplateResponse(request, 'azmayowascrumy/signup-form.html', {"form":form})
#Goal Methods
def goal_list(request):
    goals=ScrumyGoal.objects.all()
    return HttpResponse(goals)
def goal_detail(request,goal_id):
    goal=get_object_or_404(ScrumyGoal,pk=goal_id)
    return HttpResponse(goal)
def add_goal(request):
    form = AddGoalForm(request.POST or None)
    if request.user.is_authenticated:
        if request.method == "POST":
            goal = ScrumyGoal()
            form = AddGoalForm(request.POST, instance=goal)
            if form.is_valid():
                form.scrumy_user=get_object_or_404(ScrumyUser,username=request.user)
                form.save()
            else:
                return HttpResponse(form)
        else:
            return HttpResponse(form)
    else:
        return HttpResponse("Please log in")
def move_goal(request,task_id):
    pass
#Task methods
def tasks_list(request):
    tasks=ScrumyTask.objects.all()
    return HttpResponse(tasks)
def task_detail(request,task_id):
    return HttpResponse()
def add_task(request,goal_id):
    form = AddGoalForm(request.POST or None)
    if request.user.is_authenticated:
        if request.method == "POST":
            task = ScrumyTask()
            form = AddGoalForm(request.POST, instance=task)
            if form.is_valid():
                new_task=form.save(commit=False)
                new_task.save()

            else:
                return HttpResponse(form)
        else:
            return HttpResponse(form)
    else:
        return HttpResponse("Please log in")