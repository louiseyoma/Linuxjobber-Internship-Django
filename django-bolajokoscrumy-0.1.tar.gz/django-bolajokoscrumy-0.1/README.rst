=====
bolajokoscrumy
=====

Scrumy is a simple django application based on some concepts of Scrum that helps organize and manage your projects.

Quick start
-----------

1. Add "bolajokoscrumy" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'bolajokoscrumy',
    ]

2. Include the bolajokoscrumy URLconf in your project urls.py like this::

    path('bolajokoscrumy/', include('bolajokoscrumy.urls')),

3. Run `python manage.py migrate` to create the bolajokoscrumy models.

4. Start the development server and visit http://127.0.0.1:8000/
