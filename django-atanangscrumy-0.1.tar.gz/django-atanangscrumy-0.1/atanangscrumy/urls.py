from django.conf.urls import url
from atanangscrumy import views
from django.urls import include, path

urlpatterns = [
    # url(r'^$', views.homepage, name='homepage'),
    #path('atanangscrumy/<str:usersView>/', views.addTask, name='addtask'),
    # url(r'^$', views.homepage, name='homepage'),
    url('atanangscrumy/homepage', views.homepage, name='homepage'),
    path('atanangscrumy/user/new', views.addUser, name='addUser'),
    path('atanangscrumy/', views.home, name='home'),
    path('atanangscrumy/<str:username>/', views.findUser, name='users'),
]
