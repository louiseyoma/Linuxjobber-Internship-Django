from django.apps import AppConfig


class EmmascrumyConfig(AppConfig):
    name = 'emmascrumy'
