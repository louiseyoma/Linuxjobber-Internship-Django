from django.apps import AppConfig


class BolajokoscrumyConfig(AppConfig):
    name = 'bolajokoscrumy'
