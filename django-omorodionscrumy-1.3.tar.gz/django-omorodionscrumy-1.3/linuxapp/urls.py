
from django.urls import path
from . import views

app_name = 'linuxapp'

urlpatterns = [
    path('homepage/',views.HomePage.as_view(), name='homepage'),
    path('linuxapp/addTask/', views.AddTask.as_view(), name = 'addTask'),
    path('linuxapp/user/new/', views.AddUser.as_view(), name = 'addUser'),
    #path('accounts/login', views.login , name='login'),
    path('accounts/login/redirect', views.redirect, name='redirect'),
    path('homepage/move/<int:pk>/', views.MoveTask.as_view() , name='move'),
    path('home', views.test, name= 'home'),
]


