from django import forms
from django.forms import ModelForm
from .models import ScrumyUser, ScrumyGoal

class AddUser(forms.ModelForm):
    class Meta:
        model = ScrumyUser
        fields = '__all__'

class AddTask(forms.ModelForm):
    class Meta:
        model = ScrumyGoal
        fields = '__all__'

class ChangeTask(forms.ModelForm):
    class Meta:
        model = ScrumyGoal
        fields=['level']