from django.shortcuts import render,redirect
from django.template import loader
from django.http import HttpResponse,Http404
from .models import UserName,TaskId,Taskcategory
from linuxapp.forms import newUser,newTask
from django.contrib.auth.models import Group
from django.contrib.auth.decorators import login_required
from django.views.generic import ListView, DetailView,CreateView,UpdateView
# Create your views here.


class HomePage(ListView):
    template_name = 'linuxapp/home.html'

    def get(self, request):
        try:
            users = TaskId.objects.all()
        except TaskId.DoesNotExist:
            raise Http404("user does not exist")
        return render(request, self.template_name, {"users": users})

   
class AddTask(CreateView):
    template_name = 'linuxapp/addTask.html'
    model = TaskId
    fields = ['task','task_category','task_id','user_id']

    def post(self,request):
        
        if request.method == "POST":
            form = newTask(request.POST)
            if form.is_valid():
                model_instance = form.save(commit=False)
                model_instance.save()
                return redirect('/homepage')
        else:
            
            form = newTask()
            return render(request,self.template_name ,{'form': form})

class AddUser(CreateView):
    template_name = 'linuxapp/addUser.html'
    model = UserName
    fields =['userName','password']
    def post(self, request):
        
        if request.method == "POST":
            form = newUser(request.POST)
            if form.is_valid():
                model_instance = form.save(commit=False)
                model_instance.save()
                return redirect('/homepage')
                
        else:
            
            form = newUser()
            return render(request,self.template_name,{'form': form})


class MoveTask(UpdateView):
    template_name = 'linuxapp/editTask.html'
    model = TaskId
    fields = ['task_category',]

    def post (self, request,pk):
        if request.method == "POST":
            active_user = request.user
            active_user_group = Group.objects.get(user= active_user)
            task = TaskId.objects.get(pk=pk)

            if request.POST.get("task_category") == "Weekly Goal":
                task.task_category_id = 1
                task.save()
                return redirect('/homepage')

            elif request.POST.get("task_category") == "Daily Goal":
                task.task_category_id = 2
                task.save()
                return redirect('/homepage')
            elif request.POST.get("task_category") == "Verify":
                Regular = Group.objects.get(pk=2)
                if  active_user_group.pk == Regular.pk:
                        return render(request,"linuxapp/no_permission.html")
                else:
                    task.task_category_id = 3
                    task.save()
                    return redirect('/homepage')
            else:
                Regular = Group.objects.get(pk=2)
                if  active_user_group.pk == Regular.pk:
                        return render(request,"linuxapp/no_permission.html")
                else:
                    task.task_category_id = 4
                    task.save()
                    return redirect('/homepage')
        else:
            return render(request,self.template_name)


def test(request):
    people = UserName.objects.all()
    for e in people:
        y = e.userName
        return HttpResponse(y)
        