from django.shortcuts import render
from django.http import HttpResponse
from .models import ScrumyGoals, ScrumyUser


# Create your views here.


def homepage(request):
    a = ScrumyGoals.objects.all().filter(task_category='daily goals')
    return HttpResponse(a)
