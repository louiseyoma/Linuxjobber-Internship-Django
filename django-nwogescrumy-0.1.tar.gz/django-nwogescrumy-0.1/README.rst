=====
Scrumyapp
=====

Scrumyapp is a simple Django project management app for monitoring and managing projects and tasks.
Detailed documentation is in the "docs" directory.

Quick start
-----------

1. Add "scrumyapp" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'scrumyapp.apps.ScrumyappConfig',
    ]

2. Include the scrumyapp URLconf in your project urls.py like this::

    path('scrumy/', include('scrumyapp.urls')),

3. Run `python manage.py migrate` to create the scrumyapp models.

4. Start the development server and visit http://127.0.0.1:8000/admin/
   to create a poll (you'll need the Admin app enabled).

5. Visit http://127.0.0.1:8000/scrumy to start your journey of managing your team's projects.