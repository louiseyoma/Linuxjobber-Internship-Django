from django.apps import AppConfig


class AzmayowascrumyConfig(AppConfig):
    name = 'azmayowascrumy'
