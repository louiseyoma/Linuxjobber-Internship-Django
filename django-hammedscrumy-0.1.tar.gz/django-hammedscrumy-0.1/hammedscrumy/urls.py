from django.urls import path
from . import views

urlpatterns = [
    #path('<int:task_id)>/', views.user, name='user'),
    # path('goals/', views.index, name='index'),
    # path('<int:task_id)>/', views.move_goal, name='move_goal'),
    # path('', views.check, name='check'),
    # path('addusers/', views.add_user, name='add_user'),
    # path('display_all', views.display_all, name='display_all'),
    # path('<int:task_id>/', views.move_goal, name='move_goal'),

    path('', views.index, name='index'),
    path('<int:task_id>/', views.move_goal, name='move_goal'),
    path('display_all/', views.display_all, name='display_all'),
    path('adduser/', views.add_user, name='add_user'),
    path('addtask/', views.add_task, name='add_task'),
    path('<int:task_id>/change_task/', views.change_task, name='change_task'),

]
