from django.apps import AppConfig


class ScrumyappConfig(AppConfig):
    name = 'scrumyapp'
