from django.contrib.auth.hashers import make_password
from django.db import models
from django.contrib.auth.models import Group
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils import timezone
from django.contrib.auth.models import User
# Create your models here.

CHOICES=(
    (True,'Yes'),
    (False,'No')
)
# This defines the Goal Status when created

GOAL_STATUS = (
    ("P", "Pending"),
    ("I", "In-Progress"),
    ("V", "Verified"),
    ("D", "Done")
)
TASK_STATUS = (
    ("P", "Pending"),
    ("I", "In-Progress"),
    ("V", "Verified"),
    ("D", "Done")
)

# Recommended Goal Types for the Scrum
GOAL_TYPES = (
    ('D', 'Daily Goals'),
    ('W', "Weekly Goals")

)
SCRUMY_USER_ROLE = (
    ('O', 'Owner'),
    ('A', 'Admin'),
    ('Q', 'Quality Analyst'),
    ('D', 'Developer'),
)


class ScrumyGoal(models.Model):
    scrumy_user=models.ForeignKey("ScrumyUser",on_delete=models.CASCADE)
    title=models.CharField(max_length=200,null=True)
    description=models.TextField()
    goal_type=models.CharField(max_length=1,choices=GOAL_TYPES,default='D',blank=True)
    date_created=models.DateTimeField(auto_now=True,editable=False)
    date_updated=models.DateTimeField(auto_now=True)
    status=models.CharField(max_length=1,choices=GOAL_STATUS,default='P',blank=True)
    completed_on=models.DateTimeField(blank=True,null=True)
    verified_by=models.ForeignKey("ScrumyUser",on_delete=models.CASCADE,null=True,blank=True,related_name="goal_verified_by")
    verified_on=models.DateTimeField(blank=True,null=True)

    def __str__(self):
        return self.title
    def approve_goal(self,scrumy_admin):
        self.verified_by=scrumy_admin
        self.status=GOAL_STATUS[0]
        self.verified_on=timezone.now()
        self.save()
    def decline_goal(self,scrumy_admin):
        self.status=GOAL_STATUS[1]
        self.verified_by=scrumy_admin
        self.verified_on=timezone.now()
        self.save()
        self.status=GOAL_STATUS[0]

class ScrumyTask(models.Model):
    goal=models.ForeignKey("ScrumyGoal",on_delete=models.CASCADE)
    notes = models.TextField()
    assigned_to=models.ForeignKey("ScrumyUser",on_delete=models.CASCADE,related_name="assigned_to")
    assigned_by=models.ForeignKey("ScrumyUser",on_delete=models.CASCADE,related_name="assigned_by")
    assigned_on=models.DateTimeField(auto_now=True,editable=False)
    completed_on=models.DateTimeField(null=True)
    updated_on=models.DateTimeField(default=timezone.now)
    updated_by=models.ForeignKey("ScrumyUser",on_delete=models.CASCADE,related_name="updated_by")
    confirmed_by=models.ForeignKey("ScrumyUser",on_delete=models.CASCADE,related_name="confirmed_by")
    confirmed_on = models.DateTimeField(null=True)
    status=models.CharField(max_length=1,choices=TASK_STATUS,default='P')

    def __str__(self):
        return self.notes

class ScrumyUser(User):
    class Meta:
        proxy=True

def get_models():
    return [ScrumyUser,ScrumyGoal,ScrumyTask]

