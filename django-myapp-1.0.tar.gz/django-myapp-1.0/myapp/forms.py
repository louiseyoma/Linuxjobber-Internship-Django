from django.forms import ModelForm
from django import forms
from .models import ScrummyUser, ScrummyGoals, GoalStatus

class AddTaskForm(forms.ModelForm):
    class Meta:
        model = ScrummyGoals
        fields = ['task', 'user_name']


class AddUserForm(forms.ModelForm):
    class Meta:
        model = ScrummyUser
        fields = ['name', 'roles', 'password']

class ChangeTaskForm(forms.ModelForm):
    class Meta:
        model = GoalStatus
        fields = ['goal']