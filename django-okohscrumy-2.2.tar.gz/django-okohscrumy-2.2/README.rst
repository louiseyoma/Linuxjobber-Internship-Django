=====
okohscrumy
=====

okohscrumy is a simple Django app for project management among teams. 
You can add a user and assign a role, create task and assign 
tasks target and track the progress of the task and verify if task is 
completed.

Quick start
-----------

1. Add "okohscrumy" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'okohscrumy',
    ]

2. Include the polls URLconf in your project urls.py like this::

    path('okohscrumy/', include('okohscrumy.urls')),

3. Run `python manage.py migrate` to create the okohscrumy models.

4. Start the development server and visit http://127.0.0.1:8000/admin/
   to see the admin dashboard (you'll need the Admin app enabled).

5. Visit http://127.0.0.1:8000/okohscrumy/ to view the app.