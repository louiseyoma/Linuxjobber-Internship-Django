from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from .models import ScrummyUser, ScrummyGoals, GoalStatus

def index(request):
    return HttpResponse("Welcome to the homepage.")

def move_goal(request, task_id):
    var = ScrummyGoals.objects.filter(pk=task_id)
    out = " ".join([q.task_target for q in var])
    return HttpResponse("The goal target for id %s is %s"%(task_id, out))


def add_task(request, task_id):
    var = ScrummyGoals.objects.filter(pk=task_id)
    out = " ".join([q.task for q in var])
    return HttpResponse("The goal for id %s is %s" % (task_id, out))

def add_user(request):
   # var = ScrummyUser.objects.create(name=user, email=email, roles=role)
    var1 = ScrummyUser.objects.all()
    out = " , ".join([q.name for q in var1])
    return HttpResponse(out)


