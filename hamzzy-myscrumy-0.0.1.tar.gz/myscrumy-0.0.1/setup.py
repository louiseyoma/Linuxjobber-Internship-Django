from setuptools import setup

setup(
    name='myscrumy',
    version='0.0.1',
    packages=['myscrumy', 'hamzatmyscrumy', 'hamzatmyscrumy.migrations'],
    url='',
    license='BSD',
    author='hackgiri',
    author_email='hamat.ibrahim3@gmail.com',
    description='a scrum app for task monintoring'
)
