from django.apps import AppConfig


class AdesokanscrumyConfig(AppConfig):
    name = 'adesokanscrumy'
