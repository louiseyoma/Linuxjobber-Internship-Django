from django.apps import AppConfig


class GreyscrumyConfig(AppConfig):
    name = 'greyscrumy'
