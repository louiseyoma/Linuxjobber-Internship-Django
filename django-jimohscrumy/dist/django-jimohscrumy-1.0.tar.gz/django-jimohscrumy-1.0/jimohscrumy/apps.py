from django.apps import AppConfig


class JimohscrumyConfig(AppConfig):
    name = 'jimohscrumy'
