from django import forms

from .models import User, Goal

class UserForm(forms.ModelForm):

    class Meta:
        model = User
        fields = ('user', 'first_name', 'last_name')


class GoalForm(forms.ModelForm):

    class Meta:
        model = Goal
        fields =  '__all__'