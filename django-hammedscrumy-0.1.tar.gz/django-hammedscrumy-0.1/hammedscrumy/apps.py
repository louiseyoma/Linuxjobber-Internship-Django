from django.apps import AppConfig


class HammedscrumyConfig(AppConfig):
    name = 'hammedscrumy'
