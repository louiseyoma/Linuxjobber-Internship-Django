from django.test import TestCase, Client
from django.urls import resolve
# Create your tests here.
from .views import Index

class RandomTest(TestCase):
    def test_b(self):
        self.assertEqual(1+1,2)
class IndexTest(TestCase):
    def test_home(self):
            client = Client()
            response = client.get('scrum/task/5/')
            self.assertEqual(response.status_code, 200)

