from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import render, HttpResponse
from .models import ScrumyGoals, ScrumyUser


# Create your views here.
def homepage(request):
    return HttpResponse('<h1>Hello World!</h1>')
  

def homepage(request):
    a = ScrumyGoals.objects.all()
    return HttpResponse(a)
