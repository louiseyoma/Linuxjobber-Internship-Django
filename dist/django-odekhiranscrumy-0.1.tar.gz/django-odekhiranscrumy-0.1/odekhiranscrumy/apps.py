from django.apps import AppConfig


class OdekhiranscrumyConfig(AppConfig):
    name = 'odekhiranscrumy'
