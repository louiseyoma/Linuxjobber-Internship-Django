from django.forms import ModelForm
from linuxapp.models import UserName,TaskId,Taskcategory


class newUser(ModelForm):
    class Meta:
        model = UserName
        fields =['userName','password']

class newTask(ModelForm):
    class Meta:
        model = TaskId
        fields = ['task','task_category','task_id','user_id']

'''class editTask(ModelForm):
    class Meta:
        model = TaskId
        fields = ['task_category']'''

    