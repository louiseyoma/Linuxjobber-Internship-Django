from django import forms
from .models import ScrumyUser, ScrumyGoals, GoalStatus

class RegistrationForm(forms.ModelForm):
    name = forms.CharField(label="Name", max_length=100)
    email = forms.CharField(label="Email", max_length=150)
    roles = forms.CharField(label="Roles", max_length=50)
    password = forms.CharField(label="Password", max_length=20, widget=forms.PasswordInput)

    class Meta:
        model = ScrumyUser
        fields = ['name','email','roles','password']

class AddTasks(forms.ModelForm):
    # user = forms.ForeignKey(label="")
    goalName = forms.CharField(label="Task", max_length=100)
    desc = forms.CharField(label="Description", max_length=250)
    date = forms.DateField(label="Date")
    time = forms.TimeField(label="Time")

    class Meta:
        model = ScrumyGoals
        fields = ['goalName','desc','date','time']

class MoveGoal(forms.Form):
    name = forms.CharField(label="Goal Status", max_length=100)