from django.shortcuts import render
from django.http import HttpResponse
from .models import ScrumyUser

def index(request):
    return HttpResponse("Hello World")

def add_task_view(request,task_id):
    return HttpResponse("This is the task number %s." % task_id)

def add_user(request):
    user = ScrumyUser.objects.all()
    output = ', '.join([me.username for me in user])
    return HttpResponse(output)

